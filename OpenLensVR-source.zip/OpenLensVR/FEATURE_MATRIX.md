# OpenLens VR feature matrix (source-level status, 2026-11-13)

| System | Implementation delivered | Device-verified? | Remaining limitations |
|---|---|---|---|
| Independent stereo rig | Yes, two eye cameras + compositor | NO | Viewport orientation and XR camera initialization need check |
| Asymmetric eye projection | Yes | NO | Physical screen measurements required |
| Adjustable radial lens distortion | Yes | NO | Lens calibration and edge behavior need validation |
| Rotational UV timewarp | Yes, CPU-late pose + per-eye shader | NO | Same-frame only; not an async compositor; GPU flip/sign test |
| Bounded pose prediction | Yes, angular velocity estimator (<= 12ms) | NO | May overpredict at hand tremor / fast turns |
| ARCore 6DoF | ARCore Input System path + AR session | NO | Need actual XR loader and OEM test |
| 3DoF fallback/recenter | Yes, attitude input | NO | Landscape orientation sign OEM-dependent |
| Hand model | Official MediaPipe Tasks Java API integration | NO | Official `.task` model downloaded separately |
| Single hand, 21 joints | Yes | NO | Depth is an assumption, not measured |
| Hand prediction and smoothing | Yes, One Euro and bounded speed estimate | NO | Thresholds require test data |
| Robust pinch detection | Dual threshold + two-frame confirmation | NO | Calibrate false positives/negatives |
| Gaze/pinch click | Yes | NO | Requires usable camera view and room lighting |
| Nearby grasp/release | Yes | NO | Not full Quest interaction semantics |
| Empty-space double pinch recenter | Yes | NO | Requires two reliable pinch events |
| Optional volume short/long | Experimental Android decor listener | NO | Off by default; unreliable OEM capture |
| World-space calibration and onboarding | Yes | NO | Physical calibration data unknown |
| Status HUD / edge warning | Yes | NO | Comfort/readability test needed |
| Audio/haptic feedback | Yes / opt-in haptic | NO | Subjective and device validation pending |
| Adaptive eye scale | Yes | NO | In-place texture allocation could hitch |
| Adaptive hand inference | Yes | NO | MediaPipe load/thermal behavior unmeasured |
| Severe-heat 3DoF protection | Yes | NO | Suspends ARCore, therefore hand capture stops |
| AR plane detection | Component included; disabled for initial performance | NO | Opt-in scan UX not built |
| Unity compilation | NOT RUN | NO | Requires Unity 6.3 Editor and Android build modules |
| APK build/install | NOT RUN | NO | Requires physical Android / Unity build |
| 10–15 minute sustained test | NOT RUN | NO | Device thermal validation required |
| Two hands / binocular passthrough | Deliberately NOT implemented | N/A | Explicit non-goals |

## Hand tracking v2 changes (source written, hardware unverified)

- 21-joint wrist-relative 3D shape from MediaPipe metric landmarks, with normalized-Z fallback; **not measured absolute depth**.
- Frame-by-frame prediction, adaptive One Euro smoothing, 2-result stable hand acquisition, pinch edge veto and temporary loss recovery.
- Camera image 0/90/180/270 degree orientation options and calibrated palm span control.
- Persistent Android bitmap for reduced GC and `inferenceMs` reporting; actual FPS and color/rotation validation pending.
- EditMode tests authored; **not run in Unity**.
