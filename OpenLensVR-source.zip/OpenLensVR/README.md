# OpenLens VR — Independent Android smartphone VR prototype (Hand Tracking v2)

**Hand upgrade:** See [`HAND_TRACKING_UPGRADE.md`](HAND_TRACKING_UPGRADE.md). v2 enhances single-hand geometry, per-frame prediction, reliability and camera-orientation calibration; Unity and device validation remain pending.

Copyright 2026 OpenLensVR contributors. Original source under Apache-2.0 (see `LICENSE`).

A standalone, **original** Unity 6 smartphone VR prototype targeting OnePlus Nord CE5. This is **not** a CardboardXR, brenpoly, Google Cardboard XR Plugin, or Google Cardboard SDK fork. It uses standard Unity XR/AR Foundation and the public on-device MediaPipe Tasks API. No controller or additional sensor is required.

**Build status: Source authored and static checks performed. The Unity project has NOT been compiled in this environment. It is NOT a verified APK.** Timewarp, camera alignment, Android Gradle plugin, pose tracking, and 10–15 minute thermals require actual Unity/phone validation.

## 1. Unity environment

- Unity Editor: **Unity 6.3 (6000.3.x)**; use Android Build Support + Android SDK, NDK, OpenJDK.
- Packages in `Packages/manifest.json`: AR Foundation 6.3.5, ARCore XR Plugin 6.3.5, XR Management, XR Core Utils, Input System, uGUI, Test Framework.
- **Built-in Render Pipeline, not URP.** This deliberate choice ensures stable camera render order and uses `Camera.onPreCull` for the compositor. It is still compatible with ARCore pose and CPU camera capture when AR camera background rendering is off.
- Android target: API 29+, ARM64, IL2CPP, OpenGLES3 and landscape-left.
- In **Project Settings > XR Plug-in Management > Android**, **enable ONLY Google ARCore**. Do not enable OpenXR, CardboardXR or any other XR provider. Unity requires the corresponding XR loader for ARCore subsystems to start.
- Set **Project Settings > Player > Active Input Handling** to **Input System Package** (or Both), and allow camera permission.
- If Unity Package Manager reports a locked core package version mismatch for your installed Editor patch, use the Editor's matching package versions and record the resolutions; do not silently upgrade AR Foundation and ARCore independently.

## 2. Install the official MediaPipe model

Run on a machine with access to Google Cloud Storage:

```powershell
python Tools/fetch_model.py
```

This obtains the official 21-landmark task bundle into `Assets/StreamingAssets/hand_landmarker.task`. Download manually from the URL printed in the script if blocked. The model is **not** embedded in this source ZIP because network download was unavailable in the creation environment. Do not confuse a missing model with a functioning hand tracker. The official model and its licensing are third-party resources; this project's original code uses Apache-2.0.

The Android AAR dependency is resolved from Maven Central at build time through `Assets/Plugins/Android/OpenLensMediaPipe.androidlib/build.gradle` (`com.google.mediapipe:tasks-vision:0.10.21`); Java model execution is off the Unity main thread. No camera is opened in Java; it receives ARCore CPU images from Unity.

## 3. Create demo scene and build

1. Open the `OpenLensVR` directory with Unity Hub **using Unity 6000.3.x**. Let packages resolve. If it asks to install TextMeshPro, it is not required by the source.
2. Click **OpenLens VR > 1. Configure Android Player**. Review changes; use your own unique application ID before shipping.
3. Click **OpenLens VR > 2. Generate Independent Demo Scene**. It creates `Assets/OpenLens/Scenes/OpenLensDemo.unity`, configures camera, AR Session, XR Origin, stereo cameras at runtime, hand worker, world UI, HUD, and a grabbable cube.
4. Open **Project Settings > XR Plug-in Management > Android** and enable the **Google ARCore** loader; fix ARCore Project Validation issues. Do not rely on this step being automated.
5. Attach OnePlus Nord CE5 over USB with developer options and USB debugging enabled. Use **Build and Run**, grant the camera permission, verify MediaPipe model loaded and `Hand AI` status available.
6. **Wear the viewer only in a safe, clear, well-lit area while seated.** Its cameras do not provide real binocular vision. Remove headset immediately if dizziness, heat discomfort, or tracking instability occurs.

## 4. How each subsystem works

| Namespace | Responsibility |
| --- | --- |
| `Stereo` | Independent two-eye RenderTextures, asymmetric frustums, lens polynomial, late rotational reprojection in a third ordered camera |
| `Tracking` | ARCore handheld pose via Input System, 3DoF attitude fallback, recenter, bounded angular velocity prediction |
| `Hands` | ARCore CPU image conversion, JNI to MediaPipe VIDEO worker, 21 landmarks, 3D visual estimate, One-Euro smoothing, pinch hysteresis |
| `Interaction` | World-space physics-targeted gaze buttons, pinch click, empty-space double pinch recenter, nearby object grab, optional cues |
| `UI` | Persistent calibration, first-run guidance, status warnings |
| `Performance` | Stable 60 fps target, consecutive-window quality/hysteresis, hand inference throttling, 3DoF thermal protection |
| `Platform` | Android thermal APIs, opt-in best-effort volume key listener |

## 5. Crucial limitations

1. **Application-level timewarp, not Quest asynchronous timewarp**: new pose sampled before the compositor draws in the *same Unity frame*. It cannot fix runtime GPU misses after its submission. Verify on-device A/B. Out-of-range pixels are black. Only orientation is reprojected; no translation reconstruction, disocclusion or spacewarp.
2. **6DoF depends on ARCore lighting/features**. 3DoF attitude fallback axes and pose continuity need validation on Nord CE5.
3. **Single rear camera does not supply real hand depth or binocular passthrough**. Hand depth estimates assume a palm width and pinhole camera intrinsics; visual scale is adjustable. Avoid precise finger-poke UX.
4. **One hand only**; no simulated second hand. Tracking field of view is hardware-limited; edge feedback is visible.
5. **Volume control interception is experimental and off by default**. Android view-level key handlers can be bypassed by some Android OEMs and do not replace a physical controller. The panel can always be operated via gaze plus pinch.
6. **Thermal policy cannot guarantee 60 fps or a 15-minute uninterrupted session.** Thermal APIs may report unknown, and CPU camera conversion and JNI may incur costs. Actual performance is unmeasured.
7. **Display and headset values are placeholder calibrations**. The screen physical width, lens distance, IPD, and distortion must be measured; do not assume default values prevent double vision.
8. **Background AR video is not enabled**. The app is intentionally a virtual environment with room-tracking and hand input, not safety-rated passthrough.
9. **No production signing, Play Store compliance, accounts, telemetry, multiplayer or two-hand support**. Use safe test builds until verification.

## 6. Timewarp math

Given the rendering head orientation `Q_r`, a late headset orientation `Q_l`, and an intended output ray `d_l` in late camera coordinates:

```
d_r = inverse(Q_r) * Q_l * d_l
uv_previous = project(P_eye, d_r)
```

The shader performs the projective UV lookup after applying adjustable radial distortion mapping; all pixels outside the original eye texture return black. Per-eye `P_eye` is asymmetric. Testing must establish orientation/texture UV signs on the Nord CE5 in landscape-left, since this static build cannot observe device rendering.

## 7. Performance and logging

Initial 60 fps target. Policy evaluates moving-average frame time once per second; downscale after 3 slow windows, upscale after 10 good windows. `HandHz` drops from 20 to 10 for thermal warnings, 0 when severe 3DoF protection applies; recovery requires 20 cool windows. Android thermal reads are no faster than 10-second intervals. Test with `adb logcat -s Unity OpenLensHandWorker`.

## 8. Test artifacts

See `TEST_PROTOCOL.md` for device testing and `FEATURE_MATRIX.md` for implemented versus unverified systems. `Tools/validate_project.py` performs a source-level integrity check, not Unity compilation. All new C# and Java files are authored under Apache-2.0.
