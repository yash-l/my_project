@echo off
setlocal
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0BUILD-APK.ps1"
if errorlevel 1 (
  echo.
  echo Build failed. See the output above and OpenLensVR-Android-build.log.
  pause
  exit /b 1
)
echo.
echo Build finished. Look in Builds\OpenLensVR-NordCE5-debug.apk
pause
