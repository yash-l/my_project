#!/usr/bin/env python3
"""Offline static checks only; cannot replace Unity C# compile, Android Gradle or hardware testing."""
import json
from pathlib import Path
import re
ROOT = Path(__file__).resolve().parents[1]
REQUIRED = [
 'Assets/OpenLens/Runtime/Stereo/StereoCompositor.cs',
 'Assets/OpenLens/Runtime/Stereo/OpticalMath.cs',
 'Assets/OpenLens/Shaders/TimewarpAndOptics.shader',
 'Assets/OpenLens/Runtime/Tracking/HeadPoseProvider.cs',
 'Assets/OpenLens/Runtime/Tracking/PosePredictor.cs',
 'Assets/OpenLens/Runtime/Hands/SingleHandTracker.cs',
 'Assets/OpenLens/Runtime/Hands/HandMath.cs',
 'Assets/Plugins/Android/OpenLensMediaPipe.androidlib/src/main/java/org/openlensvr/bridge/OpenLensHandWorker.java',
 'Assets/OpenLens/Runtime/Interaction/FocusAndPinch.cs',
 'Assets/OpenLens/Runtime/UI/CalibrationPanel.cs',
 'Assets/OpenLens/Runtime/Performance/QualityPolicy.cs',
 'Assets/OpenLens/Editor/OpenLensProjectCreator.cs',
 'README.md', 'FEATURE_MATRIX.md', 'TEST_PROTOCOL.md', 'LICENSE'
]
checks = []
checks.append(('all key modules present', all((ROOT / x).is_file() for x in REQUIRED)))
json_files = [ROOT / 'Packages/manifest.json'] + list((ROOT / 'Assets').rglob('*.asmdef'))
try:
 for p in json_files: json.loads(p.read_text(encoding='utf-8'))
 checks.append(('UPM manifest and asmdef JSON valid', True))
except Exception as e: checks.append((f'JSON valid ({e})', False))
files = list((ROOT/'Assets/OpenLens').rglob('*.cs')) + list((ROOT/'Assets/Plugins/Android').rglob('*.java'))
checks.append(('all original code carries Apache identifier', all('SPDX-License-Identifier: Apache-2.0' in p.read_text() for p in files)))
source = '\n'.join(p.read_text() for p in files)
checks.append(('no CardboardXR/br enpoly source namespace dependency', not re.search(r'using\s+(CardboardXR|brenpoly)\b', source, re.I)))
checks.append(('MediaPipe worker returns 21 points', 'setNumHands(1)' in source and 'NormalizedLandmark' in source and 'JointCount = 21' in source))
checks.append(('timewarp and safety shader guards present', 'ray.z <= 0.001' in (ROOT/'Assets/OpenLens/Shaders/TimewarpAndOptics.shader').read_text() and 'uv.x < 0' in (ROOT/'Assets/OpenLens/Shaders/TimewarpAndOptics.shader').read_text()))
checks.append(('severe thermal policy and recovery present', 'coolWindows >= 20' in source and 'HeatStatus.Severe' in source))
checks.append(('NUnit tests authored', len(list((ROOT/'Assets/OpenLens/Tests').rglob('*Tests.cs'))) > 0))
checks.append(('official model bundle NOT pretended present', (ROOT/'Assets/StreamingAssets/hand_landmarker.task').exists() or (ROOT/'Tools/fetch_model.py').is_file()))
for name, ok in checks: print(('PASS' if ok else 'FAIL') + ': ' + name)
print('STATIC CHECKS:', sum(ok for _,ok in checks), '/', len(checks))
print('No Unity compilation or Android phone testing performed.')
raise SystemExit(0 if all(ok for _,ok in checks) else 1)
