#!/usr/bin/env python3
"""Fetch public MediaPipe task bundle. This does not download a Unity/CardboardXR project."""
from pathlib import Path
from urllib.request import Request, urlopen
import hashlib

URL = 'https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task'
TARGET = Path(__file__).resolve().parents[1] / 'Assets' / 'StreamingAssets' / 'hand_landmarker.task'
if __name__ == '__main__':
    req = Request(URL, headers={'User-Agent':'OpenLensVR-model-fetch/1.0'})
    try:
        with urlopen(req, timeout=45) as response:
            raw = response.read()
        if len(raw) < 1000000:
            raise ValueError('Unexpectedly small response; not a model bundle')
        TARGET.parent.mkdir(parents=True, exist_ok=True)
        TARGET.write_bytes(raw)
        print('Model saved:', TARGET)
        print('Size:', len(raw), 'SHA-256:', hashlib.sha256(raw).hexdigest())
    except Exception as exc:
        raise SystemExit(f'Model fetch failed: {exc}. Download from {URL} and put it at {TARGET}')
