#!/usr/bin/env python3
"""Conservative, offline source/integration checks. DOES NOT compile in Unity or run on Android."""
import json
import re
from pathlib import Path
root = Path(__file__).resolve().parents[1]

def check(title, result):
    print(('PASS' if result else 'FAIL') + ': ' + title)
    return bool(result)

files = {
 'hand': 'Assets/OpenLens/Runtime/Hands/SingleHandTracker.cs',
 'math': 'Assets/OpenLens/Runtime/Hands/HandMath.cs',
 'orientation': 'Assets/OpenLens/Runtime/Hands/HandImageOrientation.cs',
 'gate': 'Assets/OpenLens/Runtime/Hands/HandObservationGate.cs',
 'android': 'Assets/Plugins/Android/OpenLensMediaPipe.androidlib/src/main/java/org/openlensvr/bridge/OpenLensHandWorker.java',
 'head': 'Assets/OpenLens/Runtime/Tracking/HeadPoseProvider.cs',
 'tests': 'Assets/OpenLens/Tests/EditMode/HandTrackingV2Tests.cs',
 'settings': 'Assets/OpenLens/Runtime/Core/SettingsStore.cs',
 'hud': 'Assets/OpenLens/Runtime/UI/StatusDisplay.cs'
}
exists = {name: (root/path).exists() for name,path in files.items()}
checks=[check('all v2 modules present', all(exists.values()))]
if not all(exists.values()): raise SystemExit(1)
contents = {k: (root/v).read_text(encoding='utf8') for k,v in files.items()}
checks.append(check('MediaPipe single hand and world joint outputs',
    'setNumHands(1)' in contents['android'] and 'worldLandmarks()' in contents['android'] and 'handedness()' in contents['android']))
checks.append(check('hand world projection not flat',
    'ModelZInMeters' in contents['hand'] and 'NormalizedZInMeters' in contents['hand'] and 'jointRange' in contents['hand']))
checks.append(check('timestamp association, drop stale result',
    'lastAcceptedId' in contents['hand'] and 'capture.cameraPose' in contents['hand'] and 'busy.compareAndSet(false, true)' in contents['android']))
checks.append(check('late-display frame updates & velocity cap',
    'void LateUpdate()' in contents['hand'] and 'predictionHorizonSeconds' in contents['hand'] and 'Vector3.ClampMagnitude' in contents['hand']))
checks.append(check('camera rotation inverse and model calibration',
    'UnrotateUv' in contents['orientation'] and 'RotateRgba' in contents['orientation'] and 'assumedPalmWidthMeters' in contents['settings']))
checks.append(check('pinch hysteresis + edge guard',
    'closeVotes >= 2' in contents['math'] and 'openVotes >= 2' in contents['math'] and 'edgePinchVetoMargin' in contents['hand']))
checks.append(check('camera offset accessor wired',
    'GetApproximateRearCameraPose' in contents['head'] and 'GetApproximateRearCameraPose()' in contents['hand']))
checks.append(check('no simulated second hand, no upstream fork namespace',
    'setNumHands(2)' not in contents['android'] and not re.search(r'using\s+(CardboardXR|brenpoly)', '\n'.join(contents.values()), re.I)))
checks.append(check('NUnit coverage authored', contents['tests'].count('[Test') >= 10))
checks.append(check('independent package schemas valid',
    all(json.loads(p.read_text()) is not None for p in [root/'Packages/manifest.json', *root.glob('Assets/**/*.asmdef')])))
checks.append(check('all new source files Apache-2.0',
    all('SPDX-License-Identifier: Apache-2.0' in s for s in contents.values() if 'class ' in s or 'package ' in s)))
print('\nSource checks passed:',sum(checks),'/',len(checks))
print('NOT a Unity compile test, MediaPipe Gradle resolution, or Nord CE5 performance test.')
raise SystemExit(0 if all(checks) else 1)
