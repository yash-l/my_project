# Hardware testing protocol — OnePlus Nord CE5

Never claim an item complete until it has a build log and actual phone evidence. Perform testing in a safe seated position, with clear physical surroundings.

## Gate A: Editor and Android build

- [ ] Unity 6000.3.x imports every dependency with zero `Packages` resolution errors.
- [ ] `OpenLens VR > 1` runs successfully; ARM64+IL2CPP, OpenGLES3, landscape-left, min API 29 confirmed.
- [ ] Unity XR Plug-in Management Android tab has only Google ARCore checked; Project Validation passes.
- [ ] `OpenLens VR > 2` generates scene and that scene loads in Play Mode without compile errors.
- [ ] Official `hand_landmarker.task` file exists and Android Gradle resolves MediaPipe Tasks Maven dependency.
- [ ] EditMode tests: all pass (`Window > General > Test Runner`).
- [ ] Build and Run: Android APK starts and camera permission prompt appears.

## Gate B: Stereo + timewarp (mandatory before enabling hand UX)

- [ ] Viewer lenses aligned mechanically; physically measure distance between lenses and screen, and enter approximate values.
- [ ] Confirm correct per-eye image orientation and no swapping/mirror of left/right textures.
- [ ] Inspect checkerboard/stationary scene: straight lines and edges, vignetting, black edges; adjust K1/K2.
- [ ] Slow yaw/head roll/pitch with timewarp **OFF vs ON**, record camera footage at 120/240fps if possible; compare latency, jitter, border shape.
- [ ] Verify moving head does not cause a reverse-sign warp (if it does, turn timewarp OFF; fix projection/UV convention before further testing).
- [ ] ARCore 6DoF head translation should move scene correctly; remove texture/lighting to trigger 3DoF fallback.
- [ ] Recenter resets forward heading without abrupt roll or position shift.

## Gate C: Hand pipeline

- [ ] Check that native worker logs `Hand landmarker initialized`; HUD shows tracked vs unavailable accurately.
- [ ] Test whether camera CPU image needs mirroring/rotation. Use visually marked Left/Right and Up/Down hand motion.
- [ ] Verify 21 landmarks against actual fingers; if colors/axes wrong correct Android RGBA/bitmap channel order.
- [ ] Test one hand only, across center, edges, 20–80 cm in good lighting; log failures.
- [ ] 30 pinch/release repetitions: count false positives, missed closes, stuck states, latency.
- [ ] Near-edge visual warning should occur before tracking disappears; gaze remains available.
- [ ] Two pinches in empty space recenter; gaze at panel button plus pinch clicks once per pinch.
- [ ] Grab demo cube within hand proximity; release and recover after tracking interruption.

## Gate D: Thermal stability

- [ ] Cold-start 15-minute seated test: log mean/frame p95/p99, eye scale, model callback rate, `getCurrentThermalStatus`, headroom.
- [ ] Verify 60 fps target within budget; count spikes >33ms, quality downscales, recovered scale.
- [ ] Verify severe-heat protection actually suspends ARCore; HUD says 3DoF; model capture ceases.
- [ ] Once cool, verify ARCore relaunch/relocalization and hand inference work again.
- [ ] Repeat with screen brightness low/medium/high, airplane mode, and with charging disconnected.
- [ ] If excessive heat, drop inference/eye scale earlier; the app must not force unbounded performance.

## Gate E: UX and safety

- [ ] World-space canvas readable in both eyes and no double text or eye strain.
- [ ] Complete onboarding and restart: values persist.
- [ ] Volume control is OFF by default, optional test with short click / long menu; ensure default Android volume still works if feature disabled.
- [ ] Display wakes during session; remove viewer safely when tracking lost or severe thermal warning.
- [ ] No camera frames sent to a network server; confirm offline operation after initial model/package installation.

## Logs to keep per test

Device model, Android/Unity versions, CPU/GPU frame timings, min/avg/p95/p99 frame time, thermal status, model inference Hz, duration, camera orientation, IPD/distortion values, timewarp flag, reprojection sign, APK hash, build log.

## Gate C v2 additions

- [ ] Test camera image rotation settings 0/90/180/270; confirm one orientation gives stable open-palm tracking.
- [ ] Measure palm knuckle span with ruler; enter value, compare estimated depth vs distances at 30/50/70 cm.
- [ ] Record joints front/side (non-flat finger z), confirm world/normalized Z orientation is not inverted.
- [ ] A/B compare per-frame prediction vs disabled (set `predictionHorizonSeconds` to 0) in 120/240 FPS video.
- [ ] 30 pinches, 30 releases; 10 pinches at edge; count false clicks, sticky holds, rejected frames.
- [ ] Validate handedness changes while rotating wrist; it is classification confidence, not tracking quality.
- [ ] Log p50/p95/p99 MediaPipe inferenceMs, CPU frame conversion time, result age, render frame-time spikes and heat.
