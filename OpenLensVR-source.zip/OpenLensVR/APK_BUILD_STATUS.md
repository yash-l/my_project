# OpenLensVR Android APK — actual build status

- **APK exists in this package? NO.** This environment has no Unity Editor, Unity 6.3 Android Build Support, Android SDK/NDK or attached OnePlus Nord CE5.
- This package contains independent Unity source plus an **unexecuted Windows one-click build helper**. Do not present `BUILD-APK.cmd` as a generated APK.
- The official MediaPipe model is not included. The script downloads it from Google's official model storage on the build PC; if unavailable it fails loudly instead of shipping a fake hand tracker.
- Requires Unity 6000.3.x installed and activated with Android Build Support modules. Double-click `BUILD-APK.cmd` in the `OpenLensVR` folder to attempt an ARM64 debug APK build.
- On success Unity writes `Builds/OpenLensVR-NordCE5-debug.apk`. On failure the last 75 log lines appear in the console, and the full log is `OpenLensVR-Android-build.log`. Upload the log for analysis.
- Build entrypoint `Assets/OpenLens/Editor/OpenLensBatchBuild.cs` configures Android, attempts to configure the ARCore loader, generates the scene and calls Unity BuildPipeline.
- **Still unverified:** Unity C# compilation, ARCore loader initialization, Java/Gradle MediaPipe dependency resolution, model performance, timewarp direction, shader correctness, 10–15 minute thermals, all on-device hand-tracking behavior.
- Do not run headset tests while walking or near obstacles; single rear-camera virtual environment is not a safe passthrough viewer.
