# OpenLens VR — single-hand tracker v2

## Status

Source implementation only. **No Unity 6000.3 compilation, Nord CE5 APK install, measured jitter, measured hand FPS or 15-minute thermal run was performed.** Existing v1 is preserved. This independent implementation does not depend on CardboardXR or any Google Cardboard XR plugin.

## Source fixes delivered

1. **Non-flat finger skeleton** — requests MediaPipe `worldLandmarks()` alongside normalized landmarks; uses wrist-relative metric joint Z when valid. Falls back to normalized wrist-relative z. Absolute palm range is still **monocular estimated depth**, not real-world measurement. Each joint is unprojected with its own z before being transformed into the calibrated/recentered camera pose.
2. **Smoother tracked motion** — variable-cutoff One Euro filters for each joint, bounded estimated velocity, display-frame prediction in `LateUpdate`. No extrapolation after loss; no fake second hand.
3. **Stronger pinch state** — two accepted observations to close/open, distinct thresholds, edge veto, no false release from a clipped hand. Input remains off for an incompletely acquired hand.
4. **Stale/false detection control** — unique frame IDs, 32-slot capture-to-pose ring, rejected out-of-order results, two-frame acquisition, out-of-image/short palm validation, edge-on palm depth freeze, wrist teleport check and timed loss recovery.
5. **Camera rotation calibration** — optional 0°/90°/180°/270° CPU image rotation before inference. Returned normalized points are inverse-rotated before intrinsics-based unprojection. Does **not** guess Nord CE5's raw camera orientation. Inspect Gate C first.
6. **Camera offset** — subtracts the camera-to-eyes offset from the recentered head pose before placing hand joints. It is still an estimate at frame acquisition, not a hardware timestamp-matched pose.
7. **Performance** — worker keeps one bitmap per size, reuses managed RGBA buffers, drops pending frames while busy, and provides actual on-device inference milliseconds. Existing thermal governor's `TargetInferenceHz` setting remains intact.
8. **UX** — HUD displays searching, unstable, edge, inference latency; calibration screen adds camera rotation and measured palm span in 2 mm steps.

## Calibration instructions (do this with the viewer off initially)

1. After **Gate A (Unity build)** and **Gate B (stereo/head/timewarp)** pass, fetch the official `hand_landmarker.task` and enable the hand bridge.
2. Hold one well-lit hand in front of the rear camera, 30–60 cm away. If no hand appears, cycle `CAMERA ROTATION` through 0/90/180/270 degrees. Identify the correct mode by stable detection, not by the guessed phone sensor orientation.
3. Move fingers **right/left/up/down** and confirm the skeleton follows in the same direction. If not, try `mirrorCameraX`/`mirrorCameraY` and *then* check whether Unity AR camera pose/intrinsics match the raw CPU image. Do not compensate for a pose mismatch merely with a mirror flag.
4. Measure **index MCP to pinky MCP** across the knuckles (not overall palm width), input in millimeters using the +/- controls. For example, `78 mm` is only an initial assumption, not a measured value for this person.
5. Test pinch/release 30 times in the image center, then at the left/right edges, 20/30/50/80 cm and under several lighting levels. Record accidental pinch, missed pinch, hand loss, p95 inference time, age and estimated depth error.
6. Disable timewarp for initial camera geometry tests so you do not confuse reprojection failure with landmark alignment.

## Important remaining risks

- Single camera is still limited by physical FOV, blur, hand self-occlusion, rolling-shutter/AR camera timing and ambiguous world depth. **Perfect tracking is physically impossible without more viewpoints/sensors**; do not position UI buttons so close to the camera that the palm is cropped.
- MediaPipe VIDEO output `handedness()` score means classification confidence, **not** reliability that the detected hand exists. This code does not pretend that value is a hand-presence probability.
- ARCore frame timestamps and historical head poses are not truly synchronized; the capture pose is obtained at CPU-image submission. Confirm delay and drift with filmed tests before trying precise finger touches.
- When the user moves the hand too fast, conservative rejection will drop some frames. Optimize thresholds with Nord CE5 logs rather than preemptively reducing safety gates.
- Rotation correction and Android RGBA channel order require actual camera image validation; adding a generic OpenGL texture flip is not a verified solution.
- Java/Gradle integration may require Unity 6.3-specific Android dependency work; successful source checks are not a substitute for compilation.

## Tests and logs

- NUnit `HandTrackingV2Tests.cs`: image rotation, projection Z, filtering reset, pinch edge gating and teleport checks.
- Open Unity Test Runner, run all EditMode tests, capture output.
- Log model startup, accepted/rejected frames, hand result age, callbacks per second, inferenceMs, thermal and `HandTrackingQuality`.
- Attach video and build logs before claiming Gate C success.

## Recommended next milestone

**Build in Unity 6000.3, pass Gate A and B unchanged, then run Gate C on the Nord CE5.** Improve with real observations (raw camera rotation, projection sign, p95 latency, palm scale). Never claim Quest-equivalent accuracy from a single camera.
