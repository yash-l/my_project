# Copyright 2026 OpenLensVR contributors. SPDX-License-Identifier: Apache-2.0
# Build an Android APK from a local, activated Unity 6.3 editor.
param([switch]$SkipModelDownload)
$ErrorActionPreference = 'Stop'
$project = $PSScriptRoot
$log = Join-Path $project 'OpenLensVR-Android-build.log'
$apk = Join-Path $project 'Builds/OpenLensVR-NordCE5-debug.apk'
$manifest = Join-Path $project 'Packages/manifest.json'
if (-not (Test-Path $manifest)) { throw 'Unity project not found. Run inside the extracted OpenLensVR folder.' }
$hub = Join-Path ${env:ProgramFiles} 'Unity/Hub/Editor'
if (-not (Test-Path $hub)) { throw 'Unity Hub editor installation not found. Install Unity 6000.3.x + Android Build Support (SDK/NDK/OpenJDK) first.' }
$editor = Get-ChildItem -Path $hub -Directory | Where-Object { $_.Name -like '6000.3*' } | Sort-Object Name -Descending | Select-Object -First 1
if (-not $editor) { throw 'Unity 6000.3.x not installed. Install it from Unity Hub with Android Build Support.' }
$unity = Join-Path $editor.FullName 'Editor/Unity.exe'
if (-not (Test-Path $unity)) { throw "Unity.exe missing: $unity" }
Write-Host "OpenLensVR: Unity $($editor.Name)"
$model = Join-Path $project 'Assets/StreamingAssets/hand_landmarker.task'
if (-not (Test-Path $model)) {
    if ($SkipModelDownload) { throw 'Hand model missing. This build never substitutes a mock model.' }
    Write-Host 'Obtaining official MediaPipe hand model...'
    $script = Join-Path $project 'Tools/fetch_model.py'
    $py = Get-Command py -ErrorAction SilentlyContinue
    if ($py) { & py -3 $script }
    elseif (Get-Command python -ErrorAction SilentlyContinue) { & python $script }
    else { throw 'Python missing. Install Python and run Tools/fetch_model.py, or place official hand_landmarker.task in Assets/StreamingAssets.' }
    if ($LASTEXITCODE -ne 0) { throw 'MediaPipe model download failed.' }
}
if ((Get-Item $model).Length -lt 1000000) { throw 'Invalid/incomplete MediaPipe model bundle.' }
Write-Host 'Starting Unity Android development build. Log:' $log
$args = @('-batchmode','-quit','-accept-apiupdate','-buildTarget','Android','-projectPath',"`"$project`"",'-executeMethod','OpenLensVR.Editor.OpenLensBatchBuild.BuildAndroid','-logFile',"`"$log`"")
$proc = Start-Process -FilePath $unity -ArgumentList $args -Wait -PassThru
if ($proc.ExitCode -ne 0 -or -not (Test-Path $apk)) {
    if (Test-Path $log) { Get-Content $log -Tail 75 }
    throw "Build failed: Unity exit code $($proc.ExitCode). Full log: $log"
}
Write-Host 'APK CREATED:' $apk
Write-Host 'Debug build only; performance and eye comfort must be tested on device.'
