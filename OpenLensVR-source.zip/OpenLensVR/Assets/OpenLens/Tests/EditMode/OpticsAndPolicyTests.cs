// Copyright 2026 OpenLensVR contributors. SPDX-License-Identifier: Apache-2.0
using NUnit.Framework;
using OpenLensVR.Core;
using OpenLensVR.Hands;
using OpenLensVR.Performance;
using OpenLensVR.Platform;
using OpenLensVR.Stereo;
using UnityEngine;
namespace OpenLensVR.Tests
{
    public sealed class OpticsAndPolicyTests
    {
        [Test] public void LateRotationIdentityDoesNotMovePixel()
        {
            var proj = OpticalMath.EyeProjection(false,.063f,.155f,.07f,.042f,.05f,20f);
            var uv = new Vector2(.27f,.62f);
            var result = OpticalMath.ReprojectUv(uv, proj, Quaternion.identity, Quaternion.identity);
            Assert.That(Vector2.Distance(result,uv), Is.LessThan(.00001f));
        }
        [Test] public void DistinctEyeProjectionsAreAsymmetric()
        {
            var l = OpticalMath.EyeProjection(false,.063f,.155f,.07f,.042f,.05f,20f);
            var r = OpticalMath.EyeProjection(true,.063f,.155f,.07f,.042f,.05f,20f);
            Assert.That(Mathf.Abs(l[0,2]-r[0,2]), Is.GreaterThan(.01f));
        }
        [Test] public void NoUnnecessaryQualityOscillation()
        {
            var p = new QualityPolicy(); var first = p.Evaluate(16.5f,HeatStatus.None,float.NaN,QualityMode.Balanced);
            for(int i=0;i<8;i++) p.Evaluate(16.5f,HeatStatus.None,float.NaN,QualityMode.Balanced);
            var next = p.Evaluate(16.5f,HeatStatus.None,float.NaN,QualityMode.Balanced);
            Assert.That(next.EyeScale, Is.EqualTo(first.EyeScale));
        }
        [Test] public void SevereHeatProtectsPositionTracking()
        {
            var p = new QualityPolicy();
            var d = p.Evaluate(19,HeatStatus.Severe,.96f,QualityMode.Performance);
            Assert.IsTrue(d.Protect3Dof);
            Assert.That(d.HandHz,Is.EqualTo(0));
        }
        [Test] public void PalmSpanMapsToFiniteDepth()
        {
            Assert.That(HandMath.EstimateDepth(new Vector2(20,30),new Vector2(100,30),200),Is.InRange(.18f,1.2f));
        }
        [Test] public void PinchNeedsTwoClosedResults()
        {
            var p = new PinchLogic();
            Assert.IsFalse(p.Update(.2f,true,false));
            Assert.IsTrue(p.Update(.2f,true,false));
            Assert.IsTrue(p.IsPinching);
            Assert.IsFalse(p.Update(.5f,true,true)); // edge blocks spurious release
        }
    }
}
