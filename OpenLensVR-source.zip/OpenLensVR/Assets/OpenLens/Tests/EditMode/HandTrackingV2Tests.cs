// Copyright 2026 OpenLensVR contributors. SPDX-License-Identifier: Apache-2.0
using NUnit.Framework;
using OpenLensVR.Hands;
using UnityEngine;

namespace OpenLensVR.Tests
{
    public sealed class HandTrackingV2Tests
    {
        [TestCase(0, 3, 2)]
        [TestCase(90, 2, 3)]
        [TestCase(180, 3, 2)]
        [TestCase(270, 2, 3)]
        public void CameraRgbaRotationPreservesPixels(int angle, int width, int height)
        {
            byte[] source = new byte[3 * 2 * 4];
            for (int i = 0; i < 6; i++) source[i * 4] = (byte)(i + 1);
            byte[] output = new byte[source.Length];
            HandImageOrientation.RotateRgba(source, output, 3, 2, angle);
            var dimensions = HandImageOrientation.Dimensions(3, 2, angle);
            Assert.That(dimensions.x, Is.EqualTo(width));
            Assert.That(dimensions.y, Is.EqualTo(height));
            bool[] seen = new bool[7];
            for (int i = 0; i < 6; i++)
            {
                byte value = output[i * 4];
                Assert.That(value, Is.InRange(1, 6));
                Assert.IsFalse(seen[value]);
                seen[value] = true;
            }
        }

        [TestCase(0)] [TestCase(90)] [TestCase(180)] [TestCase(270)]
        public void UnrotateOfCenterDoesNotMove(int angle)
        {
            var uv = HandImageOrientation.UnrotateUv(new Vector2(.5f, .5f), angle);
            Assert.That(uv.x, Is.EqualTo(.5f).Within(1e-6f));
            Assert.That(uv.y, Is.EqualTo(.5f).Within(1e-6f));
        }

        [Test]
        public void WorldJointDepthIsNotForcedFlat()
        {
            float z = HandMath.NormalizedZInMeters(-.10f, .40f, 320f, 250f);
            Assert.That(z, Is.LessThan(-.04f));
            float measuredRelative = HandMath.ModelZInMeters(-.02f, .02f, .06f, .078f);
            Assert.That(measuredRelative, Is.LessThan(-.045f));
        }

        [Test]
        public void ValidButOffscreenLandmarkArrayFailsQualityGate()
        {
            var pts = new LandmarkerPoint[HandMath.JointCount];
            for (int i = 0; i < pts.Length; i++) pts[i] = new LandmarkerPoint { x = .5f, y = .5f, z = 0 };
            pts[HandMath.IndexMcp].x = .35f;
            pts[HandMath.PinkyMcp].x = .65f;
            Assert.IsTrue(HandObservationGate.Check(pts, 320, 180, out _, out _));
            for (int i = 0; i < 6; i++) pts[i].x = -2f;
            Assert.IsFalse(HandObservationGate.Check(pts, 320, 180, out _, out _));
        }

        [Test]
        public void PinholeDepthRejectsOccludedPalm()
        {
            Assert.IsTrue(float.IsNaN(HandMath.EstimateDepth(Vector2.zero, Vector2.one, 300)));
        }

        [Test]
        public void PinchRejectsEdgeAndRequiresStableClosure()
        {
            var logic = new PinchLogic();
            for (int i = 0; i < 8; i++) logic.Update(.12f, true, true);
            Assert.IsFalse(logic.IsPinching);
            logic.Update(.24f, true, false);
            Assert.IsFalse(logic.IsPinching);
            logic.Update(.24f, true, false);
            Assert.IsTrue(logic.IsPinching);
            logic.Update(.68f, true, true);
            Assert.IsTrue(logic.IsPinching);
            logic.Update(.68f, true, false);
            logic.Update(.68f, true, false);
            Assert.IsFalse(logic.IsPinching);
        }

        [Test]
        public void FilterResetsAfterTimeGapWithoutExploding()
        {
            var filter = new OneEuroVector();
            filter.Update(Vector3.zero, 1.0);
            var result = filter.Update(new Vector3(.1f, 0, 0), 1.03);
            Assert.That(result.x, Is.InRange(0f, .1f));
            result = filter.Update(new Vector3(.3f, 0, 0), 2.0);
            Assert.That(result.x, Is.EqualTo(.3f).Within(1e-6f));
        }

        [Test]
        public void SideOnPalmHasAmbiguousDepth()
        {
            float sideOn = HandObservationGate.PalmFacingQuality(
                Vector2.zero, new Vector2(1f, 1f), new Vector2(2f, 2f));
            float front = HandObservationGate.PalmFacingQuality(
                Vector2.zero, new Vector2(1f, 0f), new Vector2(0f, 1f));
            Assert.That(sideOn, Is.LessThan(.01f));
            Assert.That(front, Is.GreaterThan(.99f));
        }

        [Test]
        public void AbsurdTeleportRejectedWithoutRuiningSlowMovement()
        {
            Assert.IsTrue(HandObservationGate.ImplausibleJump(Vector3.zero, Vector3.one, .03f));
            Assert.IsFalse(HandObservationGate.ImplausibleJump(Vector3.zero, new Vector3(.02f,0f,0f), .03f));
        }

        [Test]
        public void MissingCameraMetricsNeverCreateFiniteFakeDepth()
        {
            Assert.IsTrue(float.IsNaN(HandMath.EstimateDepth(new Vector2(0,0), new Vector2(50,0),0)));
        }
    }
}
