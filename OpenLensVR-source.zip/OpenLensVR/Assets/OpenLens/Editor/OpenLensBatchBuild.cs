// Copyright 2026 OpenLensVR contributors. SPDX-License-Identifier: Apache-2.0
#if UNITY_EDITOR
using System;
using System.IO;
using UnityEditor;
using UnityEditor.Build;
using UnityEditor.Build.Reporting;
using UnityEditor.XR.Management;
using UnityEditor.XR.Management.Metadata;
using UnityEngine;
using UnityEngine.XR.Management;

namespace OpenLensVR.Editor
{
    /// <summary>
    /// Build entry point for unattended Unity 6.3 Android development builds.
    /// The machine must have a legitimately activated Unity Editor and Android Build Support.
    /// Run with -buildTarget Android to select the platform before Editor assemblies load.
    /// </summary>
    public static class OpenLensBatchBuild
    {
        private const string ArCoreLoaderName = "UnityEngine.XR.ARCore.ARCoreLoader";
        private const string Scene = "Assets/OpenLens/Scenes/OpenLensDemo.unity";

        [MenuItem("OpenLens VR/3. Generate Test APK")]
        public static void BuildAndroid()
        {
            if (EditorUserBuildSettings.activeBuildTarget != BuildTarget.Android)
                throw new BuildFailedException("Select Android first, or launch Unity with -buildTarget Android.");

            var model = Path.Combine(Application.dataPath, "StreamingAssets/hand_landmarker.task");
            if (!File.Exists(model) || new FileInfo(model).Length < 1000000)
                throw new BuildFailedException("Real MediaPipe hand model missing. Run python Tools/fetch_model.py before building. No placeholder model will be shipped.");

            // Unity's Android target is set in the CLI before this method runs.
            OpenLensProjectCreator.ConfigurePlayer();
            InstallArCoreLoader();
            OpenLensProjectCreator.GenerateScene();
            if (!File.Exists(Path.Combine(Directory.GetParent(Application.dataPath).FullName, Scene)))
                throw new BuildFailedException("Failed to generate the OpenLens demo scene.");

            EditorUserBuildSettings.buildAppBundle = false;
            PlayerSettings.Android.useCustomKeystore = false; // Unity debug signing for local testing only.
            AssetDatabase.SaveAssets();

            var builds = Path.Combine(Directory.GetParent(Application.dataPath).FullName, "Builds");
            Directory.CreateDirectory(builds);
            var apk = Path.Combine(builds, "OpenLensVR-NordCE5-debug.apk");
            Debug.Log("[OpenLensBuild] Building Android ARM64 debug APK: " + apk);
            var options = new BuildPlayerOptions
            {
                scenes = new [] { Scene },
                locationPathName = apk,
                target = BuildTarget.Android,
                options = BuildOptions.Development | BuildOptions.AllowDebugging
            };
            var report = BuildPipeline.BuildPlayer(options);
            if (report == null || report.summary.result != BuildResult.Succeeded || !File.Exists(apk))
                throw new BuildFailedException("Unity Android build failed. See Editor.log for compiler or Gradle errors.");
            Debug.Log("[OpenLensBuild] SUCCESS " + apk + " bytes=" + new FileInfo(apk).Length);
        }

        private static void InstallArCoreLoader()
        {
            const string storePath = "Assets/OpenLensXRSettings.asset";
            XRGeneralSettingsPerBuildTarget configurations;
            if (!EditorBuildSettings.TryGetConfigObject(XRGeneralSettings.settingsKey, out configurations) || configurations == null)
            {
                configurations = ScriptableObject.CreateInstance<XRGeneralSettingsPerBuildTarget>();
                AssetDatabase.CreateAsset(configurations, storePath);
                EditorBuildSettings.AddConfigObject(XRGeneralSettings.settingsKey, configurations, true);
            }

            // Create the Android settings without touching unrelated platform settings.
            var android = configurations.SettingsForBuildTarget(BuildTargetGroup.Android);
            if (android == null)
            {
                configurations.CreateDefaultSettingsForBuildTarget(BuildTargetGroup.Android);
                android = configurations.SettingsForBuildTarget(BuildTargetGroup.Android);
            }
            if (android == null)
                throw new BuildFailedException("Failed to create Android XR settings.");
            if (android.Manager == null)
            {
                configurations.CreateDefaultManagerSettingsForBuildTarget(BuildTargetGroup.Android);
                android = configurations.SettingsForBuildTarget(BuildTargetGroup.Android);
            }
            if (android.Manager == null)
                throw new BuildFailedException("Failed to create XR Manager settings.");

            android.InitManagerOnStart = true;
            if (!XRPackageMetadataStore.AssignLoader(android.Manager, ArCoreLoaderName, BuildTargetGroup.Android))
                throw new BuildFailedException("ARCore loader not available. Check com.unity.xr.arcore and XR Plug-in Management packages.");

            EditorUtility.SetDirty(android);
            EditorUtility.SetDirty(android.Manager);
            EditorUtility.SetDirty(configurations);
            Debug.Log("[OpenLensBuild] ARCore XR loader selected for Android.");
        }
    }
}
#endif
