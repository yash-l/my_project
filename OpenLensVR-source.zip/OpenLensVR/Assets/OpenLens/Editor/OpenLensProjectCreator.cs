// Copyright 2026 OpenLensVR contributors. SPDX-License-Identifier: Apache-2.0
#if UNITY_EDITOR
using OpenLensVR.Hands;
using OpenLensVR.Interaction;
using OpenLensVR.Performance;
using OpenLensVR.Platform;
using OpenLensVR.Stereo;
using OpenLensVR.Tracking;
using OpenLensVR.UI;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEditor.Build;
using UnityEngine;
using UnityEngine.XR.ARFoundation;
using Unity.XR.CoreUtils;

namespace OpenLensVR.Editor
{
    public static class OpenLensProjectCreator
    {
        const string ScenePath = "Assets/OpenLens/Scenes/OpenLensDemo.unity";

        [MenuItem("OpenLens VR/1. Configure Android Player")]
        public static void ConfigurePlayer()
        {
            EditorUserBuildSettings.SwitchActiveBuildTarget(BuildTargetGroup.Android, BuildTarget.Android);
            PlayerSettings.companyName = "OpenLensVR";
            PlayerSettings.productName = "OpenLens VR";
            PlayerSettings.SetApplicationIdentifier(NamedBuildTarget.Android, "org.openlensvr.viewer");
            PlayerSettings.SetScriptingBackend(NamedBuildTarget.Android, ScriptingImplementation.IL2CPP);
            PlayerSettings.Android.targetArchitectures = AndroidArchitecture.ARM64;
            PlayerSettings.Android.minSdkVersion = AndroidSdkVersions.AndroidApiLevel29;
            PlayerSettings.defaultInterfaceOrientation = UIOrientation.LandscapeLeft;
            PlayerSettings.SetUseDefaultGraphicsAPIs(BuildTarget.Android, false);
            PlayerSettings.SetGraphicsAPIs(BuildTarget.Android, new[] { UnityEngine.Rendering.GraphicsDeviceType.OpenGLES3 });
            PlayerSettings.Android.forceInternetPermission = false; // Maven dependencies are resolved at build, not app runtime.
            QualitySettings.vSyncCount = 0;
            Debug.Log("[OpenLens] Player configured. IMPORTANT: XR Plug-in Management > Android > enable ONLY Google ARCore; disable Cardboard/OpenXR.");
        }

        [MenuItem("OpenLens VR/2. Generate Independent Demo Scene")]
        public static void GenerateScene()
        {
            if (!AssetDatabase.IsValidFolder("Assets/OpenLens/Scenes"))
                AssetDatabase.CreateFolder("Assets/OpenLens", "Scenes");
            var scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
            var arSessionGo = new GameObject("AR Session");
            var arSession = arSessionGo.AddComponent<ARSession>();
            arSessionGo.AddComponent<ARInputManager>();

            var originGo = new GameObject("Tracking Origin");
            var origin = originGo.AddComponent<XROrigin>();
            var offsetGo = new GameObject("Camera Offset");
            offsetGo.transform.SetParent(originGo.transform, false);
            var camGo = new GameObject("AR Device Camera");
            camGo.transform.SetParent(offsetGo.transform, false);
            camGo.tag = "MainCamera";
            var arCam = camGo.AddComponent<Camera>();
            arCam.depth = -100;
            arCam.clearFlags = CameraClearFlags.SolidColor;
            arCam.backgroundColor = Color.black;
            arCam.cullingMask = 0; // Camera handles ARCore capture only, never overlays a monoscopic image.
            arCam.allowHDR = false; arCam.allowMSAA = false;
            var cameraManager = camGo.AddComponent<ARCameraManager>();
            origin.Camera = arCam;
            origin.CameraFloorOffsetObject = offsetGo;
            var planeManager = originGo.AddComponent<ARPlaneManager>();
            planeManager.enabled = false; // Opt-in scanning: CPU budget belongs to hand inference.

            var root = new GameObject("OpenLens System");
            var pose = root.AddComponent<HeadPoseProvider>();
            pose.Configure(arSession, cameraManager, originGo.transform);
            var stereo = root.AddComponent<StereoCompositor>();
            stereo.Configure(pose, Shader.Find("OpenLensVR/TimewarpAndOptics"));
            var worker = new GameObject("OpenLensHandBridge");
            var hand = worker.AddComponent<SingleHandTracker>();
            hand.Configure(cameraManager, pose);
            new GameObject("Hand Skeleton").AddComponent<SingleHandView>();
            var platform = new GameObject("Android Status").AddComponent<AndroidDeviceStatus>();
            var perf = new GameObject("Adaptive Quality").AddComponent<AdaptiveQualityController>();
            var ui = new GameObject("World Calibration").AddComponent<CalibrationPanel>();
            ui.Configure(pose);
            new GameObject("Status HUD").AddComponent<StatusDisplay>();
            var feedback = new GameObject("Interaction Feedback").AddComponent<PresenceFeedback>();
            var interact = new GameObject("Gaze and Pinch").AddComponent<FocusAndPinch>();
            interact.Configure(pose, hand, ui, feedback);
            new GameObject("Optional Volume (off by default)").AddComponent<OptionalVolumeControls>();

            // Minimal hands-on scene with a real 3D object, not a mocked hand or mock input.
            var cube = GameObject.CreatePrimitive(PrimitiveType.Cube);
            cube.name = "Demo Grab Cube";
            cube.transform.position = new Vector3(0, -.15f, 1.4f);
            cube.transform.localScale = Vector3.one * .12f;
            var cubeMaterial = new Material(Shader.Find("Unlit/Color"));
            cubeMaterial.color = new Color(.27f, .70f, .94f);
            cube.GetComponent<Renderer>().sharedMaterial = cubeMaterial;
            cube.AddComponent<WorldGrabbable>();

            EditorSceneManager.SaveScene(scene, ScenePath);
            EditorBuildSettings.scenes = new[] { new EditorBuildSettingsScene(ScenePath, true) };
            AssetDatabase.SaveAssets();
            Debug.Log("[OpenLens] Scene generated at " + ScenePath + ". Enable Google ARCore loader before Build & Run.");
        }
    }
}
#endif
