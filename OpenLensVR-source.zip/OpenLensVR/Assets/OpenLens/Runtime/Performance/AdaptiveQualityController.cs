// Copyright 2026 OpenLensVR contributors. SPDX-License-Identifier: Apache-2.0
using OpenLensVR.Core;
using OpenLensVR.Platform;
using OpenLensVR.Stereo;
using OpenLensVR.Tracking;
using OpenLensVR.Hands;
using UnityEngine;

namespace OpenLensVR.Performance
{
    public sealed class AdaptiveQualityController : MonoBehaviour
    {
        [SerializeField] StereoCompositor compositor;
        [SerializeField] HeadPoseProvider head;
        [SerializeField] SingleHandTracker hand;
        [SerializeField] AndroidDeviceStatus device;
        readonly QualityPolicy policy = new QualityPolicy();
        float averageMs = 16.67f, nextDecision;
        public QualityDecision Current { get; private set; } = new QualityDecision(.85f, 20, false);
        public float MeanFrameMs => averageMs;
        void Awake()
        {
            if (!compositor) compositor = FindFirstObjectByType<StereoCompositor>();
            if (!head) head = FindFirstObjectByType<HeadPoseProvider>();
            if (!hand) hand = FindFirstObjectByType<SingleHandTracker>();
            if (!device) device = FindFirstObjectByType<AndroidDeviceStatus>();
        }
        void Update()
        {
            if (Time.unscaledDeltaTime > 0) averageMs = Mathf.Lerp(averageMs, Mathf.Min(100, Time.unscaledDeltaTime * 1000), .025f);
            if (Time.unscaledTime < nextDecision) return;
            nextDecision = Time.unscaledTime + 1f;
            Current = policy.Evaluate(averageMs, device ? device.Heat : HeatStatus.Unknown,
                device ? device.Headroom : float.NaN, SettingsStore.Current.quality);
            if (compositor) compositor.SetResolution(Current.EyeScale);
            if (hand) hand.TargetInferenceHz = Current.HandHz;
            if (head) head.ProtectFromHeat(Current.Protect3Dof);
            Debug.Log($"[Quality] frame={averageMs:F1}ms scale={Current.EyeScale:F2} hand={Current.HandHz}Hz protect={Current.Protect3Dof}");
        }
    }
}
