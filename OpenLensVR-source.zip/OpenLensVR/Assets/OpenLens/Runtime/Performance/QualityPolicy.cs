// Copyright 2026 OpenLensVR contributors. SPDX-License-Identifier: Apache-2.0
using OpenLensVR.Core;
using OpenLensVR.Platform;
using UnityEngine;

namespace OpenLensVR.Performance
{
    public struct QualityDecision
    {
        public float EyeScale;
        public int HandHz;
        public bool Protect3Dof;
        public QualityDecision(float scale, int handHz, bool protect)
        { EyeScale = scale; HandHz = handHz; Protect3Dof = protect; }
    }

    // Pure decision logic: deliberately asymmetric hysteresis avoids scale oscillation.
    public sealed class QualityPolicy
    {
        int slowWindows, fastWindows, coolWindows;
        float scale = .85f;
        bool protecting;
        public QualityDecision Evaluate(float frameMs, HeatStatus heat, float headroom, QualityMode mode)
        {
            bool severe = heat >= HeatStatus.Severe || (!float.IsNaN(headroom) && headroom >= .94f);
            bool hot = heat >= HeatStatus.Moderate || (!float.IsNaN(headroom) && headroom >= .80f);
            if (severe) { protecting = true; coolWindows = 0; }
            else if (protecting)
            {
                if (!hot) coolWindows++; else coolWindows = 0;
                if (coolWindows >= 20) { protecting = false; coolWindows = 0; }
            }
            if (frameMs > 17.8f || hot)
            { slowWindows++; fastWindows = 0; }
            else if (frameMs < 14f && !hot)
            { fastWindows++; slowWindows = 0; }
            else { slowWindows = 0; fastWindows = 0; }
            if (slowWindows >= 3)
            { scale = Mathf.Max(.55f, scale - .05f); slowWindows = 0; }
            if (fastWindows >= 10)
            { scale = Mathf.Min(mode == QualityMode.Performance ? 1f : mode == QualityMode.Balanced ? .85f : .75f, scale + .05f); fastWindows = 0; }
            float ceiling = mode == QualityMode.Comfort ? .75f : mode == QualityMode.Balanced ? .85f : 1f;
            scale = Mathf.Min(scale, ceiling);
            if (hot) scale = Mathf.Min(scale, .75f);
            int handRate = protecting ? 0 : severe ? 0 : hot ? 10 : mode == QualityMode.Comfort ? 12 : 20;
            return new QualityDecision(scale, handRate, protecting);
        }
    }
}
