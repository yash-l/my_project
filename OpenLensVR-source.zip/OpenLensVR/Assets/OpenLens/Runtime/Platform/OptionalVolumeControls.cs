// Copyright 2026 OpenLensVR contributors. SPDX-License-Identifier: Apache-2.0
using OpenLensVR.Core;
using OpenLensVR.Interaction;
using UnityEngine;
namespace OpenLensVR.Platform
{
    public sealed class OptionalVolumeControls : MonoBehaviour
    {
        [SerializeField] FocusAndPinch interactor;
        AndroidJavaObject relay;
        bool installed;
        void Awake() { gameObject.name = "OpenLensVolume"; }
        void Start() { if (!interactor) interactor = FindFirstObjectByType<FocusAndPinch>(); }
        void Update()
        {
            bool want = SettingsStore.Current.optionalVolumeControls;
            if (want == installed) return;
#if UNITY_ANDROID && !UNITY_EDITOR
            try
            {
                if (want)
                {
                    using (var player = new AndroidJavaClass("com.unity3d.player.UnityPlayer"))
                    using (var activity = player.GetStatic<AndroidJavaObject>("currentActivity"))
                    {
                        relay = new AndroidJavaObject("org.openlensvr.bridge.OptionalVolumeRelay");
                        relay.Call("setEnabled", activity, gameObject.name, true);
                        installed = true;
                    }
                }
                else { relay?.Call("disable"); relay?.Dispose(); relay = null; installed = false; }
            }
            catch (System.Exception e) { Debug.LogWarning("[Volume] Unsupported decor-view interception: " + e.Message); installed = false; SettingsStore.Current.optionalVolumeControls = false; SettingsStore.Save(); }
#endif
        }
        public void OnVolumeMessage(string kind)
        {
            if (!SettingsStore.Current.optionalVolumeControls) return;
            if (kind == "short") interactor?.GazeClick();
            if (kind == "long") interactor?.ShowMenu();
        }
        void OnDestroy() { relay?.Call("disable"); relay?.Dispose(); }
    }
}
