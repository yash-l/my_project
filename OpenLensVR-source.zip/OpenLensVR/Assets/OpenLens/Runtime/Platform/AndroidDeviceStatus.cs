// Copyright 2026 OpenLensVR contributors. SPDX-License-Identifier: Apache-2.0
using UnityEngine;
namespace OpenLensVR.Platform
{
    public enum HeatStatus { Unknown = -1, None = 0, Light = 1, Moderate = 2, Severe = 3, Critical = 4, Emergency = 5, Shutdown = 6 }

    public sealed class AndroidDeviceStatus : MonoBehaviour
    {
        public HeatStatus Heat { get; private set; } = HeatStatus.Unknown;
        public float Headroom { get; private set; } = float.NaN;
        float nextSample;
        void Update()
        {
            if (Time.unscaledTime < nextSample) return;
            nextSample = Time.unscaledTime + 10f;
#if UNITY_ANDROID && !UNITY_EDITOR
            try
            {
                using (var player = new AndroidJavaClass("com.unity3d.player.UnityPlayer"))
                using (var activity = player.GetStatic<AndroidJavaObject>("currentActivity"))
                using (var power = activity.Call<AndroidJavaObject>("getSystemService", "power"))
                {
                    Heat = (HeatStatus)power.Call<int>("getCurrentThermalStatus");
                    using (var version = new AndroidJavaClass("android.os.Build$VERSION"))
                        if (version.GetStatic<int>("SDK_INT") >= 30)
                            Headroom = power.Call<float>("getThermalHeadroom", 0);
                }
            }
            catch (System.Exception e) { Debug.LogWarning("[Thermal] Android API unavailable: " + e.Message); }
#endif
            Debug.Log($"[Thermal] status={Heat}, headroom={Headroom:F2}, battery={SystemInfo.batteryLevel:F2}");
        }
    }
}
