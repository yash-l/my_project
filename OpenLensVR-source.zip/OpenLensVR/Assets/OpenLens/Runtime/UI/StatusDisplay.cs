// Copyright 2026 OpenLensVR contributors. SPDX-License-Identifier: Apache-2.0
using OpenLensVR.Hands;
using OpenLensVR.Tracking;
using OpenLensVR.Performance;
using OpenLensVR.Platform;
using UnityEngine;
using UnityEngine.UI;
namespace OpenLensVR.UI
{
    public sealed class StatusDisplay : MonoBehaviour
    {
        [SerializeField] HeadPoseProvider head;
        [SerializeField] SingleHandTracker hand;
        [SerializeField] AdaptiveQualityController quality;
        [SerializeField] AndroidDeviceStatus device;
        Text label;
        RectTransform panel;
        float nextUpdate;
        void Start()
        {
            if (!head) head = FindFirstObjectByType<HeadPoseProvider>();
            if (!hand) hand = FindFirstObjectByType<SingleHandTracker>();
            if (!quality) quality = FindFirstObjectByType<AdaptiveQualityController>();
            if (!device) device = FindFirstObjectByType<AndroidDeviceStatus>();
            var root = new GameObject("Spatial Status", typeof(RectTransform), typeof(Canvas));
            panel = (RectTransform)root.transform; panel.SetParent(transform,false);
            panel.sizeDelta = new Vector2(600,100); panel.localScale = Vector3.one * .0012f;
            root.GetComponent<Canvas>().renderMode = RenderMode.WorldSpace;
            var textObj = new GameObject("Status", typeof(RectTransform), typeof(Text));
            var rect = (RectTransform)textObj.transform; rect.SetParent(panel,false);
            rect.sizeDelta = panel.sizeDelta;
            label = textObj.GetComponent<Text>();
            label.font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
            label.fontSize = 20; label.color = new Color(.82f,.95f,1);
            label.alignment = TextAnchor.MiddleCenter; label.raycastTarget = false;
        }
        void LateUpdate()
        {
            if (head == null || panel == null) return;
            var pose = head.GetLatestPose();
            panel.SetPositionAndRotation(pose.position + pose.rotation * new Vector3(0,-.52f,2.2f), pose.rotation);
            if (Time.unscaledTime < nextUpdate) return;
            nextUpdate = Time.unscaledTime + .4f;
            string mode = head.Mode == HeadTrackingMode.SixDof ? "6DoF" : "3DoF / tracking limited";
            string handState = hand == null ? "Hand unavailable" : !hand.Available ? "Hand AI unavailable" :
                hand.Quality == HandTrackingQuality.Acquiring ? "Finding hand - keep palm visible" :
                !hand.HasHand ? "Hand not visible - use gaze" : hand.NearEdge ? "MOVE HAND TO CAMERA CENTER" :
                hand.Quality == HandTrackingQuality.Limited ? "Hand unstable - hold steady" :
                $"Hand stable | AI {hand.LastInferenceMs:F0} ms | callback {hand.LastCallbackDelayMs:F0} ms";
            string heat = device == null ? "Heat unknown" : device.Heat.ToString();
            bool protection = quality != null && quality.Current.Protect3Dof;
            label.text = $"{mode}  ·  {handState}  ·  Heat: {heat}" +
                (protection ? "\nTHERMAL PROTECTION: 3DoF only - stop if uncomfortable" :
                head.Mode != HeadTrackingMode.SixDof ? "\nImprove lighting and face textured surfaces" : "");
        }
    }
}
