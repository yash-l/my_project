// Copyright 2026 OpenLensVR contributors. SPDX-License-Identifier: Apache-2.0
using System;
using OpenLensVR.Core;
using OpenLensVR.Interaction;
using OpenLensVR.Tracking;
using UnityEngine;
using UnityEngine.UI;

namespace OpenLensVR.UI
{
    /// <summary>A true world-space canvas: every control has its own 3D BoxCollider for gaze.
    /// Settings are persisted and changes propagate to the optics compositor without restarting.</summary>
    public sealed class CalibrationPanel : MonoBehaviour
    {
        [SerializeField] HeadPoseProvider head;
        RectTransform canvasRect;
        Text info;
        Font font;
        bool visible;
        readonly Color textColor = new Color(.92f, .96f, 1);
        public bool IsOpen => visible;
        public void Configure(HeadPoseProvider pose) { head = pose; }
        void Start()
        {
            if (head == null) head = FindFirstObjectByType<HeadPoseProvider>();
            font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
            var go = new GameObject("World-space Calibration", typeof(RectTransform), typeof(Canvas));
            go.transform.SetParent(transform, false);
            canvasRect = (RectTransform)go.transform;
            canvasRect.sizeDelta = new Vector2(830, 790);
            canvasRect.localScale = Vector3.one * .00125f;
            var canvas = go.GetComponent<Canvas>(); canvas.renderMode = RenderMode.WorldSpace;
            CreateImage("Panel", canvasRect, Vector2.zero, new Vector2(830, 790), new Color(.035f, .055f, .09f, .96f));
            CreateText("Header", canvasRect, "OPENLENS VR · CALIBRATION", new Vector2(0, 280), 30, new Vector2(760, 55));
            info = CreateText("Status", canvasRect, "", new Vector2(0, 218), 19, new Vector2(760, 65));
            AddRow(160, "LENS SPACING / IPD", -.002f, .002f,
                () => SettingsStore.Current.interpupillaryMeters,
                v => SettingsStore.Current.interpupillaryMeters = v,
                v => $"{v * 1000f:F0} mm");
            AddRow(75, "LENS DISTORTION", -.02f, .02f,
                () => SettingsStore.Current.distortionK1,
                v => SettingsStore.Current.distortionK1 = v,
                v => v.ToString("F2"));
            AddRow(-10, "HAND DEPTH DISPLAY", -.05f, .05f,
                () => SettingsStore.Current.handDepthScale,
                v => SettingsStore.Current.handDepthScale = v,
                v => $"{v:F2} x");
            AddRow(-95, "DISTORTION HIGHER ORDER", -.01f, .01f,
                () => SettingsStore.Current.distortionK2,
                v => SettingsStore.Current.distortionK2 = v,
                v => v.ToString("F2"));
            MakeButton("Timewarp", canvasRect, new Vector2(-230,-180), new Vector2(210, 54),
                "TIMEWARP ON/OFF", () => { SettingsStore.Current.timewarp = !SettingsStore.Current.timewarp; SettingsStore.Save(); Refresh(); });
            MakeButton("Quality", canvasRect, new Vector2(0,-180), new Vector2(210, 54),
                "QUALITY MODE", () => { SettingsStore.Current.quality = (QualityMode)(((int)SettingsStore.Current.quality + 1) % 3); SettingsStore.Save(); Refresh(); });
            MakeButton("Recenter", canvasRect, new Vector2(230,-180), new Vector2(210,54),
                "RECENTER", () => { head?.Recenter(); Refresh(); });
            MakeButton("Volume", canvasRect, new Vector2(-125,-252), new Vector2(235,52),
                "VOLUME (OPTIONAL)", () => { SettingsStore.Current.optionalVolumeControls = !SettingsStore.Current.optionalVolumeControls; SettingsStore.Save(); Refresh(); });
            MakeButton("Finish", canvasRect, new Vector2(148,-252), new Vector2(235,52),
                "SAVE / CONTINUE", () => { SettingsStore.Current.hasCompletedOnboarding = true; SettingsStore.Save(); Show(false); });
            MakeButton("RotateCamera", canvasRect, new Vector2(-223,-335), new Vector2(350,54),
                "CAMERA ROTATION (90 DEG)", () =>
                {
                    SettingsStore.Current.handImageRotationDegrees =
                        (SettingsStore.Current.handImageRotationDegrees + 90) % 360;
                    SettingsStore.Save(); Refresh();
                });
            MakeButton("PalmMinus", canvasRect, new Vector2(82,-335), new Vector2(130,54),
                "PALM -", () =>
                {
                    SettingsStore.Current.assumedPalmWidthMeters -= .002f;
                    SettingsStore.Save(); Refresh();
                });
            MakeButton("PalmPlus", canvasRect, new Vector2(270,-335), new Vector2(130,54),
                "PALM +", () =>
                {
                    SettingsStore.Current.assumedPalmWidthMeters += .002f;
                    SettingsStore.Save(); Refresh();
                });
            Show(!SettingsStore.Current.hasCompletedOnboarding);
        }
        void AddRow(float y, string caption, float stepDown, float stepUp,
            Func<float> read, Action<float> write, Func<float,string> format)
        {
            CreateText(caption, canvasRect, caption, new Vector2(-155,y + 15), 19, new Vector2(445,45));
            var val = CreateText("Value", canvasRect, format(read()), new Vector2(135,y + 15), 20, new Vector2(135,45));
            MakeButton(caption+" -", canvasRect, new Vector2(265,y + 15), new Vector2(55,52), "-",
                () => { write(read() + stepDown); SettingsStore.Save(); val.text = format(read()); Refresh(); });
            MakeButton(caption+" +", canvasRect, new Vector2(340,y + 15), new Vector2(55,52), "+",
                () => { write(read() + stepUp); SettingsStore.Save(); val.text = format(read()); Refresh(); });
        }
        static Image CreateImage(string name, RectTransform parent, Vector2 pos, Vector2 size, Color color)
        {
            var go = new GameObject(name, typeof(RectTransform), typeof(Image));
            var r = (RectTransform)go.transform; r.SetParent(parent,false);
            r.anchoredPosition = pos; r.sizeDelta = size;
            var image = go.GetComponent<Image>(); image.color = color; image.raycastTarget = false;
            return image;
        }
        Text CreateText(string name, RectTransform parent, string value, Vector2 pos, int size, Vector2 bounds)
        {
            var go = new GameObject(name, typeof(RectTransform), typeof(Text));
            var r = (RectTransform)go.transform; r.SetParent(parent,false);
            r.anchoredPosition = pos; r.sizeDelta = bounds;
            var text = go.GetComponent<Text>(); text.font = font; text.text = value; text.fontSize = size;
            text.color = textColor; text.alignment = TextAnchor.MiddleCenter; text.raycastTarget = false;
            return text;
        }
        void MakeButton(string name, RectTransform parent, Vector2 pos, Vector2 size, string label, Action click)
        {
            var image = CreateImage(name, parent, pos, size, new Color(.18f,.23f,.35f));
            CreateText("Caption", image.rectTransform, label, Vector2.zero, 17, size - new Vector2(6,6));
            var collider = image.gameObject.AddComponent<BoxCollider>(); collider.size = new Vector3(size.x, size.y, 10);
            var action = image.gameObject.AddComponent<WorldPressTarget>(); action.Configure(click, image);
        }
        void Refresh()
        {
            if (info == null) return;
            var s = SettingsStore.Current;
            info.text = $"Keep seated | Bright room | One hand only | Camera rotation: {s.handImageRotationDegrees} deg\nPalm span: {s.assumedPalmWidthMeters*1000f:F0} mm  |  Timewarp: {(s.timewarp ? "ON" : "OFF")}   Quality: {s.quality}";
        }
        public void Show(bool show)
        {
            visible = show;
            if (canvasRect == null) return;
            if (show && head != null)
            {
                var pose = head.GetLatestPose();
                canvasRect.SetPositionAndRotation(pose.position + pose.rotation * new Vector3(0,-.05f,1.4f), pose.rotation);
            }
            canvasRect.gameObject.SetActive(show);
            Refresh();
        }
    }
}
