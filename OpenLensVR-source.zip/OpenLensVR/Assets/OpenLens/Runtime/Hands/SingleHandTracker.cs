// Copyright 2026 OpenLensVR contributors. SPDX-License-Identifier: Apache-2.0
using System;
using System.Collections;
using System.IO;
using OpenLensVR.Core;
using OpenLensVR.Tracking;
using Unity.Collections;
using UnityEngine;
using UnityEngine.Networking;
using UnityEngine.XR.ARFoundation;
using UnityEngine.XR.ARSubsystems;

namespace OpenLensVR.Hands
{
    [Serializable] public sealed class LandmarkerPoint { public float x, y, z; }
    [Serializable] public sealed class LandmarkerPacket
    {
        public long timestampMs;
        public int width, height;
        public float inferenceMs;
        public float handednessScore;
        public LandmarkerPoint[] points;
        public LandmarkerPoint[] worldPoints;
    }

    /// <summary>
    /// Exactly one hand; real ARCore CPU camera frames -> MediaPipe Android VIDEO worker ->
    /// timestamp-correlated 21 joints. This is *not* a 6DoF optical hand sensor. The depth of
    /// the palm is inferred from an assumed physical width and a pinhole camera. MediaPipe's
    /// model-relative joint z improves hand shape but does not make the absolute range measured.
    /// </summary>
    [DefaultExecutionOrder(-150)]
    public sealed class SingleHandTracker : MonoBehaviour
    {
        [Header("Inputs")]
        [SerializeField] ARCameraManager cameraManager;
        [SerializeField] HeadPoseProvider head;
        [SerializeField, Range(160, 640)] int captureWidth = 320;
        [SerializeField, Range(120, 480)] int captureHeight = 240;
        [Header("Tracking gates")]
        [SerializeField, Range(.15f, .8f)] float handLossSeconds = .32f;
        [SerializeField, Range(0f, .08f)] float predictionHorizonSeconds = .035f;
        [SerializeField] float edgeWarningMargin = .075f;
        [SerializeField] float edgePinchVetoMargin = .045f;

        public int TargetInferenceHz { get; set; } = 18;
        public bool Available { get; private set; }
        public bool HasHand { get; private set; }
        public bool NearEdge { get; private set; }
        public bool IsPinching => pinch.IsPinching;
        public float EstimatedDepth { get; private set; }
        public float PalmConfidence { get; private set; } // geometry / temporal confidence, not an ML probability
        public float HandednessScore { get; private set; } // left/right classifier, NOT presence confidence
        public float LastInferenceMs { get; private set; }
        // End-to-end callback delay after the frame is submitted (NOT true sensor-to-photon latency).
        public float LastCallbackDelayMs { get; private set; }
        public float LastResultAge => Time.unscaledTime - lastResultTime;
        public int ResultCount { get; private set; }
        public int RejectedResults { get; private set; }
        public HandTrackingQuality Quality { get; private set; } = HandTrackingQuality.Unavailable;
        public Vector3[] Joints { get; } = new Vector3[HandMath.JointCount];
        public event Action<bool> PinchChanged;
        public event Action<bool> TrackingChanged;
        public string Error { get; private set; } = "Hand model not loaded";

        readonly OneEuroVector[] filters = new OneEuroVector[HandMath.JointCount];
        readonly Vector3[] filteredSamples = new Vector3[HandMath.JointCount];
        readonly Vector3[] previousSamples = new Vector3[HandMath.JointCount];
        readonly Vector3[] velocities = new Vector3[HandMath.JointCount];
        readonly Vector2[] normalizedRaw = new Vector2[HandMath.JointCount];
        readonly PinchLogic pinch = new PinchLogic();

        // Frames are correlated by unique submission ID. The pose is sampled when the CPU image
        // is acquired; true sensor-time ARCore pose alignment requires device instrumentation.
        struct Capture
        {
            public long id;
            public Pose cameraPose;
            public float fx, fy, px, py;
            public int rawWidth, rawHeight, clockwiseRotation;
        }
        readonly Capture[] captures = new Capture[32];
        int captureWrite, acceptedStreak, rejectedStreak;
        long lastSentId, lastAcceptedId;
        float nextCapture, lastResultTime = -100f;
        double lastSampleTime;
        bool haveSample, preparing;
        AndroidJavaObject bridge;
        byte[] convertedRgba, rotatedRgba;
        float filteredDepth = float.NaN;
        double depthTime;

        public void Configure(ARCameraManager manager, HeadPoseProvider pose)
        { cameraManager = manager; head = pose; }

        void Awake()
        {
            gameObject.name = "OpenLensHandBridge"; // UnitySendMessage target in native Java bridge.
            for (int i = 0; i < filters.Length; i++)
                filters[i] = new OneEuroVector(i == HandMath.Wrist ? 1.35f : 1.7f, i == HandMath.Wrist ? .65f : 1.25f);
        }
        void OnEnable()
        {
            if (cameraManager == null) cameraManager = FindFirstObjectByType<ARCameraManager>();
            if (head == null) head = FindFirstObjectByType<HeadPoseProvider>();
            if (!preparing) StartCoroutine(PrepareModel());
        }
        IEnumerator PrepareModel()
        {
            preparing = true;
#if UNITY_ANDROID && !UNITY_EDITOR
            string modelPath = Path.Combine(Application.persistentDataPath, "openlens_hand_landmarker.task");
            if (!File.Exists(modelPath))
            {
                string url = Application.streamingAssetsPath + "/hand_landmarker.task";
                using (var request = UnityWebRequest.Get(url))
                {
                    yield return request.SendWebRequest();
                    if (request.result != UnityWebRequest.Result.Success)
                    {
                        Error = "Missing hand_landmarker.task: " + request.error;
                        Debug.LogWarning("[Hand] " + Error); preparing = false; yield break;
                    }
                    try { File.WriteAllBytes(modelPath, request.downloadHandler.data); }
                    catch (Exception e)
                    {
                        Error = "Could not copy hand model: " + e.Message;
                        Debug.LogError("[Hand] " + Error); preparing = false; yield break;
                    }
                }
            }
            try
            {
                using (var player = new AndroidJavaClass("com.unity3d.player.UnityPlayer"))
                using (var activity = player.GetStatic<AndroidJavaObject>("currentActivity"))
                {
                    bridge = new AndroidJavaObject("org.openlensvr.bridge.OpenLensHandWorker");
                    bridge.Call("initialize", activity, modelPath, gameObject.name);
                }
                Error = "MediaPipe worker starting";
            }
            catch (Exception e) { Error = e.Message; Debug.LogError("[Hand] " + Error); }
#else
            yield return null;
            Error = "Android MediaPipe only (no simulated hand in Editor)";
#endif
            preparing = false;
        }
        void OnDisable()
        {
            StopAllCoroutines(); preparing = false;
            if (bridge != null)
            {
                try { bridge.Call("close"); }
                catch (Exception e) { Debug.LogWarning("[Hand] Bridge close: " + e.Message); }
                bridge.Dispose(); bridge = null;
            }
            Available = false;
            LoseHand(); Quality = HandTrackingQuality.Unavailable;
        }

        void Update()
        {
            if (HasHand && LastResultAge > handLossSeconds) LoseHand();
            if (!Available || TargetInferenceHz <= 0 || cameraManager == null || head == null) return;
            if (Time.unscaledTime < nextCapture) return;
            nextCapture = Time.unscaledTime + 1f / Mathf.Clamp(TargetInferenceHz, 1, 30);
            SendFrame();
        }

        void LateUpdate()
        {
            if (!HasHand) return;
            // Predict the last filtered result forward EACH display frame (not just when an
            // inference result arrives); cap the horizon to avoid overshoot after dropped frames.
            float age = Mathf.Max(0f, (float)(Time.realtimeSinceStartupAsDouble - lastSampleTime));
            float horizon = Mathf.Min(age, predictionHorizonSeconds);
            for (int i = 0; i < Joints.Length; i++)
                Joints[i] = filteredSamples[i] + velocities[i] * horizon;
        }

        void SendFrame()
        {
            if (!cameraManager.TryAcquireLatestCpuImage(out var cpuImage)) return;
            using (cpuImage)
            {
                // Sample pose BEFORE CPU conversion; otherwise conversion time itself adds
                // extra hand-to-head alignment error. Sensor timestamp sync remains future work.
                Pose cameraPoseAtAcquire = head.GetApproximateRearCameraPose();
                // Preserve the camera sensor aspect ratio when downsizing. Independently
                // requesting 320x240 from a 16:9 sensor distorts hand shape/pinch geometry.
                float scale = Mathf.Min(1f, Mathf.Min((float)captureWidth / cpuImage.width,
                    (float)captureHeight / cpuImage.height));
                int rawWidth = Mathf.Max(16, Mathf.RoundToInt(cpuImage.width * scale));
                int rawHeight = Mathf.Max(16, Mathf.RoundToInt(cpuImage.height * scale));
                var size = new Vector2Int(rawWidth, rawHeight);
                var conversion = new XRCpuImage.ConversionParams
                {
                    inputRect = new RectInt(0, 0, cpuImage.width, cpuImage.height),
                    outputDimensions = size,
                    outputFormat = TextureFormat.RGBA32,
                    transformation = XRCpuImage.Transformation.None
                };
                try
                {
                    int bytes = cpuImage.GetConvertedDataSize(conversion);
                    using (var pixels = new NativeArray<byte>(bytes, Allocator.Temp))
                    {
                        cpuImage.Convert(conversion, pixels);
                        if (convertedRgba == null || convertedRgba.Length != bytes) convertedRgba = new byte[bytes];
                        pixels.CopyTo(convertedRgba);
                        float fx = rawWidth * .75f, fy = rawWidth * .75f;
                        float px = rawWidth * .5f, py = rawHeight * .5f;
                        if (cameraManager.TryGetIntrinsics(out var intrinsics))
                        {
                            fx = intrinsics.focalLength.x * rawWidth / intrinsics.resolution.x;
                            fy = intrinsics.focalLength.y * rawHeight / intrinsics.resolution.y;
                            px = intrinsics.principalPoint.x * rawWidth / intrinsics.resolution.x;
                            py = intrinsics.principalPoint.y * rawHeight / intrinsics.resolution.y;
                        }
                        int rotation = HandImageOrientation.Normalize(SettingsStore.Current.handImageRotationDegrees);
                        byte[] submitBytes = convertedRgba;
                        var imageSize = HandImageOrientation.Dimensions(rawWidth, rawHeight, rotation);
                        if (rotation != 0)
                        {
                            if (rotatedRgba == null || rotatedRgba.Length != bytes) rotatedRgba = new byte[bytes];
                            HandImageOrientation.RotateRgba(convertedRgba, rotatedRgba, rawWidth, rawHeight, rotation);
                            submitBytes = rotatedRgba;
                        }
                        long id = Math.Max(lastSentId + 1, (long)(Time.realtimeSinceStartupAsDouble * 1000.0));
                        lastSentId = id;
                        captures[captureWrite] = new Capture
                        {
                            id = id, cameraPose = cameraPoseAtAcquire,
                            fx = fx, fy = fy, px = px, py = py, rawWidth = rawWidth,
                            rawHeight = rawHeight, clockwiseRotation = rotation
                        };
                        captureWrite = (captureWrite + 1) % captures.Length;
                        // Byte array is marshaled into Java. Java drops frames while busy rather than
                        // processing stale backlog; both C# arrays can be reused next frame.
                        bridge?.Call("submit", submitBytes, imageSize.x, imageSize.y, id);
                    }
                }
                catch (Exception e) { Debug.LogWarning("[Hand] Frame conversion: " + e.Message); }
            }
        }

        public void OnNativeHandStatus(string status)
        {
            if (!isActiveAndEnabled) return;
            if (status == "ready")
            {
                Available = true; Error = "";
                Quality = HandTrackingQuality.Searching;
                Debug.Log("[Hand] MediaPipe worker ready");
            }
            else
            {
                Available = false; Error = status;
                Debug.LogWarning("[Hand] " + status);
            }
        }

        // Invoked by UnitySendMessage on main thread. Empty points means no detection this frame.
        public void OnNativeHandResult(string json)
        {
            if (!isActiveAndEnabled || !Available) return;
            LandmarkerPacket packet;
            try { packet = JsonUtility.FromJson<LandmarkerPacket>(json); }
            catch (Exception e) { Debug.LogWarning("[Hand] Result JSON: " + e.Message); return; }
            if (packet == null || packet.timestampMs <= lastAcceptedId) return;
            Capture capture = default;
            bool found = false;
            foreach (var candidate in captures)
                if (candidate.id == packet.timestampMs) { capture = candidate; found = true; break; }
            if (!found) return; // Reject delayed results whose camera pose was evicted.
            lastAcceptedId = packet.timestampMs;
            LastInferenceMs = packet.inferenceMs;
            LastCallbackDelayMs = Mathf.Max(0f, (float)(Time.realtimeSinceStartupAsDouble - packet.timestampMs * .001) * 1000f);
            HandednessScore = packet.handednessScore;
            if (packet.points == null || packet.points.Length != HandMath.JointCount)
            {
                acceptedStreak = 0;
                if (HasHand && LastResultAge > handLossSeconds) LoseHand();
                return;
            }
            var settings = SettingsStore.Current;
            // Model observations are in the rotated detection image. Undo that rotation before
            // projecting through the RAW camera intrinsics and placing in the tracking world.
            for (int i = 0; i < normalizedRaw.Length; i++)
            {
                var point = packet.points[i];
                if (point == null || !HandMath.Valid(point.x) || !HandMath.Valid(point.y) || !HandMath.Valid(point.z))
                { Reject("nonfinite landmark"); return; }
                Vector2 raw = HandImageOrientation.UnrotateUv(new Vector2(point.x, point.y), capture.clockwiseRotation);
                if (settings.transposeCameraXY) raw = new Vector2(raw.y, raw.x);
                if (settings.mirrorCameraX) raw.x = 1f - raw.x;
                if (settings.mirrorCameraY) raw.y = 1f - raw.y;
                normalizedRaw[i] = raw;
            }
            // Gate geometry in raw-camera space, including off-frame and palm visibility.
            float edgeMargin = .5f;
            int outside = 0;
            for (int i = 0; i < normalizedRaw.Length; i++)
            {
                var p = normalizedRaw[i];
                if (p.x < -.08f || p.x > 1.08f || p.y < -.08f || p.y > 1.08f) outside++;
                edgeMargin = Mathf.Min(edgeMargin,
                    Mathf.Min(Mathf.Min(p.x, 1f - p.x), Mathf.Min(p.y, 1f - p.y)));
            }
            float palmPixels = Vector2.Distance(Vector2.Scale(normalizedRaw[HandMath.IndexMcp], new Vector2(capture.rawWidth, capture.rawHeight)),
                Vector2.Scale(normalizedRaw[HandMath.PinkyMcp], new Vector2(capture.rawWidth, capture.rawHeight)));
            if (outside > 3 || palmPixels < 9f || palmPixels > Mathf.Max(capture.rawWidth, capture.rawHeight) * .93f)
            { Reject("implausible image geometry"); return; }
            float proposed = HandMath.EstimateDepth(
                new Vector2(normalizedRaw[HandMath.IndexMcp].x * capture.rawWidth, normalizedRaw[HandMath.IndexMcp].y * capture.rawHeight),
                new Vector2(normalizedRaw[HandMath.PinkyMcp].x * capture.rawWidth, normalizedRaw[HandMath.PinkyMcp].y * capture.rawHeight),
                capture.fx, settings.assumedPalmWidthMeters);
            if (!HandMath.Valid(proposed)) { Reject("no depth estimate"); return; }
            double resultTime = packet.timestampMs * .001;
            // An edge-on palm looks physically narrower, inflating the monocular range.
            // Freeze range rather than snapping the hand away when that geometry is ambiguous.
            float facing = HandObservationGate.PalmFacingQuality(
                normalizedRaw[HandMath.Wrist], normalizedRaw[HandMath.IndexMcp],
                normalizedRaw[HandMath.PinkyMcp]);
            bool ambiguousDepth = facing < .22f;
            if (ambiguousDepth && HandMath.Valid(filteredDepth)) proposed = filteredDepth;
            if (!HandMath.Valid(filteredDepth) || resultTime <= depthTime || resultTime - depthTime > .45)
                filteredDepth = proposed;
            else
            {
                // Limit depth jumps caused by palm rotation/occlusion before applying EMA.
                float maxMove = Mathf.Max(.04f, (float)(resultTime - depthTime) * 1.4f);
                filteredDepth = Mathf.Lerp(filteredDepth,
                    Mathf.MoveTowards(filteredDepth, proposed, maxMove), .28f);
            }
            depthTime = resultTime;
            float depth = Mathf.Clamp(filteredDepth * settings.handDepthScale, .16f, 1.4f);
            float modelWidth = 0f;
            bool hasMetric = packet.worldPoints != null && packet.worldPoints.Length == HandMath.JointCount;
            if (hasMetric)
            {
                var wm = packet.worldPoints;
                if (wm[0] == null || wm[HandMath.IndexMcp] == null || wm[HandMath.PinkyMcp] == null) hasMetric = false;
                else modelWidth = Vector3.Distance(
                    new Vector3(wm[HandMath.IndexMcp].x, wm[HandMath.IndexMcp].y, wm[HandMath.IndexMcp].z),
                    new Vector3(wm[HandMath.PinkyMcp].x, wm[HandMath.PinkyMcp].y, wm[HandMath.PinkyMcp].z));
                hasMetric &= modelWidth > .02f && modelWidth < .15f;
            }
            float dt = haveSample ? (float)(resultTime - lastSampleTime) : 0f;
            var source = packet.points;
            for (int i = 0; i < HandMath.JointCount; i++)
            {
                Vector2 pixelUv = normalizedRaw[i];
                float zOffset = hasMetric && packet.worldPoints[i] != null
                    ? HandMath.ModelZInMeters(packet.worldPoints[i].z, packet.worldPoints[0].z,
                        modelWidth, settings.assumedPalmWidthMeters)
                    : HandMath.NormalizedZInMeters(source[i].z - source[0].z, depth, capture.rawWidth, capture.fx);
                // Camera points have +Z away from camera, +Y upward. Model z is wrist-relative.
                float jointRange = Mathf.Clamp(depth + zOffset, .08f, 1.55f);
                var rayPoint = HandMath.Unproject(pixelUv.x, pixelUv.y, jointRange,
                    capture.fx, capture.fy, capture.px, capture.py, capture.rawWidth, capture.rawHeight);
                Vector3 world = capture.cameraPose.position + capture.cameraPose.rotation * rayPoint;
                if (!HandMath.Valid(world)) { Reject("invalid 3D joint"); return; }
                if (i == HandMath.Wrist && HasHand && HandObservationGate.ImplausibleJump(
                    filteredSamples[i], world, dt)) { Reject("hand teleport"); return; }
                var smooth = filters[i].Update(world, resultTime);
                velocities[i] = haveSample && dt > .008f && dt < .30f
                    ? Vector3.ClampMagnitude((smooth - previousSamples[i]) / dt, 1.8f)
                    : Vector3.zero;
                filteredSamples[i] = previousSamples[i] = smooth;
                Joints[i] = smooth;
            }
            lastSampleTime = resultTime;
            haveSample = true;
            lastResultTime = Time.unscaledTime;
            ResultCount++;
            acceptedStreak++;
            rejectedStreak = 0;
            NearEdge = edgeMargin < edgeWarningMargin;
            PalmConfidence = Mathf.Clamp01(Mathf.InverseLerp(.0f, .10f, edgeMargin));
            EstimatedDepth = depth;
            if (!HasHand && acceptedStreak >= 2)
            {
                HasHand = true;
                TrackingChanged?.Invoke(true);
            }
            Quality = !HasHand ? HandTrackingQuality.Acquiring
                : NearEdge ? HandTrackingQuality.Edge
                : ambiguousDepth ? HandTrackingQuality.Limited : HandTrackingQuality.Stable;
            if (!HasHand) return;
            // Use pixel-space distances with the original image aspect ratio.
            float pinchPixels = Vector2.Distance(
                Vector2.Scale(normalizedRaw[HandMath.ThumbTip], new Vector2(capture.rawWidth, capture.rawHeight)),
                Vector2.Scale(normalizedRaw[HandMath.IndexTip], new Vector2(capture.rawWidth, capture.rawHeight)));
            float pinchRatio = pinchPixels / Mathf.Max(1f, palmPixels);
            bool qualityForClick = edgeMargin > edgePinchVetoMargin &&
                PalmConfidence > .20f && !ambiguousDepth;
            if (pinch.Update(pinchRatio, qualityForClick, !qualityForClick))
                PinchChanged?.Invoke(pinch.IsPinching);
        }

        void Reject(string why)
        {
            RejectedResults++;
            acceptedStreak = 0;
            rejectedStreak++;
            Quality = HasHand ? HandTrackingQuality.Limited : HandTrackingQuality.Acquiring;
            if (rejectedStreak == 4)
                Debug.LogWarning("[Hand] Rejected four consecutive results: " + why);
            // Do not instantly discard the last good hand for one bad landmark frame.
            if (HasHand && LastResultAge > handLossSeconds) LoseHand();
        }
        void LoseHand()
        {
            bool wasTracking = HasHand;
            HasHand = false; NearEdge = false; PalmConfidence = 0f;
            acceptedStreak = 0; rejectedStreak = 0; haveSample = false;
            filteredDepth = float.NaN; depthTime = 0d;
            if (pinch.IsPinching) { pinch.Reset(); PinchChanged?.Invoke(false); }
            for (int i = 0; i < filters.Length; ++i) filters[i].Reset();
            Quality = Available ? HandTrackingQuality.Searching : HandTrackingQuality.Unavailable;
            if (wasTracking)
            {
                TrackingChanged?.Invoke(false);
                Debug.Log("[Hand] Tracking lost; gaze fallback remains available");
            }
        }
    }
}
