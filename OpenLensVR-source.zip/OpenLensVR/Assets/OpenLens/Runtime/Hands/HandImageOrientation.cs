// Copyright 2026 OpenLensVR contributors. SPDX-License-Identifier: Apache-2.0
using UnityEngine;

namespace OpenLensVR.Hands
{
    /// <summary>MediaPipe wants an upright hand image. Rotating CPU pixels here preserves the
    /// original sensor-space intrinsics and lets us invert the rotation on returned landmarks.
    /// Rotation is intentionally device-calibrated rather than guessed from screen orientation.</summary>
    public static class HandImageOrientation
    {
        public static int Normalize(int clockwiseDegrees)
        {
            int result = ((clockwiseDegrees % 360) + 360) % 360;
            return result == 90 || result == 180 || result == 270 ? result : 0;
        }
        public static Vector2Int Dimensions(int width, int height, int clockwiseDegrees)
            => Normalize(clockwiseDegrees) % 180 == 0
                ? new Vector2Int(width, height) : new Vector2Int(height, width);

        public static Vector2 UnrotateUv(Vector2 rotated, int clockwiseDegrees)
        {
            switch (Normalize(clockwiseDegrees))
            {
                case 90: return new Vector2(rotated.y, 1f - rotated.x);
                case 180: return new Vector2(1f - rotated.x, 1f - rotated.y);
                case 270: return new Vector2(1f - rotated.y, rotated.x);
                default: return rotated;
            }
        }

        /// <summary>CPU rotate RGBA32. No mirror or channel conversion.
        /// Reuse destination buffer across frames to prevent GC spikes.</summary>
        public static void RotateRgba(byte[] src, byte[] dst, int width, int height, int clockwiseDegrees)
        {
            if (src == null || dst == null || src.Length < width * height * 4 || dst.Length < width * height * 4)
                throw new System.ArgumentException("RGBA buffer dimensions do not match");
            int rotation = Normalize(clockwiseDegrees);
            int outWidth = rotation == 90 || rotation == 270 ? height : width;
            for (int y = 0; y < height; y++)
            for (int x = 0; x < width; x++)
            {
                int dx = x, dy = y;
                switch (rotation)
                {
                    case 90: dx = height - 1 - y; dy = x; break;
                    case 180: dx = width - 1 - x; dy = height - 1 - y; break;
                    case 270: dx = y; dy = width - 1 - x; break;
                }
                int si = (y * width + x) * 4;
                int di = (dy * outWidth + dx) * 4;
                dst[di] = src[si]; dst[di + 1] = src[si + 1];
                dst[di + 2] = src[si + 2]; dst[di + 3] = src[si + 3];
            }
        }
    }
}
