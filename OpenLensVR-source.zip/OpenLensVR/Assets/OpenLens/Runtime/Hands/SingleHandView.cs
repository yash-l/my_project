// Copyright 2026 OpenLensVR contributors. SPDX-License-Identifier: Apache-2.0
using UnityEngine;
namespace OpenLensVR.Hands
{
    [DefaultExecutionOrder(200)]
    public sealed class SingleHandView : MonoBehaviour
    {
        [SerializeField] SingleHandTracker source;
        readonly Transform[] joints = new Transform[21];
        readonly LineRenderer[] links = new LineRenderer[20];
        static readonly int[] A = {0,1,2,3,0,5,6,7,5,9,10,11,9,13,14,15,13,17,18,19};
        static readonly int[] B = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20};
        void Start()
        {
            if (source == null) source = FindFirstObjectByType<SingleHandTracker>();
            var mat = new Material(Shader.Find("Unlit/Color")); mat.color = new Color(.2f, 1f, .78f, 1);
            for (int i = 0; i < 21; i++)
            {
                var sphere = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                sphere.name = "Joint " + i;
                sphere.transform.SetParent(transform, false);
                sphere.transform.localScale = Vector3.one * (i == 0 ? .016f : .011f);
                sphere.GetComponent<Renderer>().sharedMaterial = mat;
                Destroy(sphere.GetComponent<Collider>());
                joints[i] = sphere.transform;
            }
            for (int i = 0; i < links.Length; i++)
            {
                var obj = new GameObject("Bone " + i); obj.transform.SetParent(transform, false);
                var line = obj.AddComponent<LineRenderer>();
                line.material = mat; line.positionCount = 2; line.startWidth = .005f; line.endWidth = .005f;
                line.useWorldSpace = true; links[i] = line;
            }
        }
        void LateUpdate()
        {
            bool show = source != null && source.HasHand;
            for (int i = 0; i < joints.Length; i++)
            { if (joints[i] == null) continue; joints[i].gameObject.SetActive(show); if (show) joints[i].position = source.Joints[i]; }
            for (int i = 0; i < links.Length; i++)
            {
                if (links[i] == null) continue; links[i].enabled = show;
                if (show) { links[i].SetPosition(0, source.Joints[A[i]]); links[i].SetPosition(1, source.Joints[B[i]]); }
            }
        }
    }
}
