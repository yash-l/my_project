// Copyright 2026 OpenLensVR contributors. SPDX-License-Identifier: Apache-2.0
using UnityEngine;

namespace OpenLensVR.Hands
{
    /// <summary>Geometry is approximate because one rear camera does not measure range.</summary>
    public static class HandMath
    {
        public const int JointCount = 21;
        public const int Wrist = 0, ThumbTip = 4, IndexMcp = 5, IndexTip = 8,
            MiddleMcp = 9, PinkyMcp = 17;

        public static float EstimateDepth(Vector2 a, Vector2 b, float focalPixels,
            float assumedPalmWidthMeters = .078f)
        {
            float span = Vector2.Distance(a, b);
            if (span < 5f || focalPixels <= 1f || !Valid(assumedPalmWidthMeters))
                return float.NaN;
            return Mathf.Clamp(assumedPalmWidthMeters * focalPixels / span, .16f, 1.20f);
        }

        public static Vector3 Unproject(float u, float v, float depth, float fx, float fy,
            float principalX, float principalY, float width, float height)
            => new Vector3((u * width - principalX) / Mathf.Max(1f, fx) * depth,
                -(v * height - principalY) / Mathf.Max(1f, fy) * depth, depth);

        public static bool Valid(float x) => !float.IsNaN(x) && !float.IsInfinity(x);
        public static bool Valid(Vector3 p) => Valid(p.x) && Valid(p.y) && Valid(p.z);

        /// <summary>MediaPipe normalized z is relative to wrist, with magnitude roughly like x.
        /// Convert it to meters using the camera horizontal field at the estimated hand range.</summary>
        public static float NormalizedZInMeters(float relativeZ, float depth, float imageWidth, float fx)
            => Mathf.Clamp(relativeZ * depth * imageWidth / Mathf.Max(1f, fx), -.14f, .14f);

        /// <summary>Use metric model z relative to wrist when available, scaled to the user palm.
        /// MediaPipe world landmarks are model estimates, not measured device-camera depth.</summary>
        public static float ModelZInMeters(float modelZ, float wristZ, float modelPalmWidth, float userPalmWidth)
        {
            if (!(modelPalmWidth > .02f && modelPalmWidth < .15f)) return 0f;
            return Mathf.Clamp((modelZ - wristZ) * (userPalmWidth / modelPalmWidth), -.14f, .14f);
        }
    }

    /// <summary>Adaptive low-pass filter. Reset on hand identity loss / invalid timestamp.</summary>
    public sealed class OneEuroVector
    {
        Vector3 lastValue, lastDerivative;
        double lastTime;
        bool ready;
        readonly float minCutoff, beta;
        public OneEuroVector(float minCutoff = 1.6f, float beta = 1.2f)
        { this.minCutoff = minCutoff; this.beta = beta; }
        static float Alpha(float cutoff, float dt)
        {
            float tau = 1f / (2f * Mathf.PI * Mathf.Max(.001f, cutoff));
            return 1f / (1f + tau / Mathf.Max(.001f, dt));
        }
        public void Reset() { ready = false; lastDerivative = Vector3.zero; }
        public Vector3 Update(Vector3 value, double time)
        {
            if (!HandMath.Valid(value)) return lastValue;
            if (!ready || time <= lastTime || time - lastTime > .45)
            {
                lastValue = value; lastTime = time; lastDerivative = Vector3.zero;
                ready = true; return value;
            }
            float dt = Mathf.Clamp((float)(time - lastTime), .001f, .2f);
            Vector3 derivative = Vector3.ClampMagnitude((value - lastValue) / dt, 5f);
            lastDerivative = Vector3.Lerp(lastDerivative, derivative, Alpha(1f, dt));
            float cutoff = minCutoff + beta * lastDerivative.magnitude;
            lastValue = Vector3.Lerp(lastValue, value, Alpha(cutoff, dt));
            lastTime = time;
            return lastValue;
        }
    }

    /// <summary>Pinch uses normalized thumb-index gap / palm width. Separate close/release thresholds,
    /// consecutive accepted observations, and edge/quality veto. Never generates synthetic pinches.</summary>
    public sealed class PinchLogic
    {
        readonly float close, open;
        int closeVotes, openVotes;
        public bool IsPinching { get; private set; }
        public PinchLogic(float closeRatio = .30f, float openRatio = .47f)
        { close = closeRatio; open = openRatio; }

        /// <returns>true only when the pinch state changed.</returns>
        public bool Update(float ratio, bool goodShape, bool nearEdge)
        {
            bool previous = IsPinching;
            if (!goodShape || nearEdge || !HandMath.Valid(ratio))
            {
                // Freeze an established pinch near the image edge rather than spuriously releasing;
                // SingleHandTracker resets it after a brief absence.
                closeVotes = openVotes = 0;
                return false;
            }
            if (!IsPinching)
            {
                closeVotes = ratio < close ? closeVotes + 1 : 0;
                if (closeVotes >= 2) { IsPinching = true; openVotes = 0; }
            }
            else
            {
                openVotes = ratio > open ? openVotes + 1 : 0;
                if (openVotes >= 2) { IsPinching = false; closeVotes = 0; }
            }
            return previous != IsPinching;
        }
        public void Reset() { IsPinching = false; closeVotes = openVotes = 0; }
    }
}
