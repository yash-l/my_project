// Copyright 2026 OpenLensVR contributors. SPDX-License-Identifier: Apache-2.0
using UnityEngine;

namespace OpenLensVR.Hands
{
    public enum HandTrackingQuality { Unavailable, Searching, Acquiring, Stable, Edge, Limited }

    /// <summary>Reject malformed, clipped or highly implausible hands BEFORE input events fire.
    /// MediaPipe handedness is a classification score, NOT detection confidence. We intentionally
    /// do not use it as a physical hand-presence probability.</summary>
    public static class HandObservationGate
    {
        public static bool Check(LandmarkerPoint[] points, int width, int height,
            out float edgeMargin, out float palmSpanPixels)
        {
            edgeMargin = .5f;
            palmSpanPixels = 0f;
            if (points == null || points.Length != HandMath.JointCount || width < 24 || height < 24) return false;
            int outside = 0;
            for (int i = 0; i < points.Length; ++i)
            {
                var p = points[i];
                if (p == null || !HandMath.Valid(p.x) || !HandMath.Valid(p.y) || !HandMath.Valid(p.z)) return false;
                if (p.x < -.08f || p.x > 1.08f || p.y < -.08f || p.y > 1.08f) outside++;
                edgeMargin = Mathf.Min(edgeMargin,
                    Mathf.Min(Mathf.Min(p.x, 1f - p.x), Mathf.Min(p.y, 1f - p.y)));
            }
            if (outside > 3) return false;
            palmSpanPixels = Vector2.Distance(
                new Vector2(points[HandMath.IndexMcp].x * width, points[HandMath.IndexMcp].y * height),
                new Vector2(points[HandMath.PinkyMcp].x * width, points[HandMath.PinkyMcp].y * height));
            return palmSpanPixels >= 9f && palmSpanPixels < Mathf.Max(width, height) * .93f;
        }

        /// <summary>Image-space palm area normalized by wrist-to-knuckle distances. Values near
        /// zero mean an edge-on palm: apparent knuckle span then becomes a poor depth cue.</summary>
        public static float PalmFacingQuality(Vector2 wrist, Vector2 indexMcp, Vector2 pinkyMcp)
        {
            Vector2 a = indexMcp - wrist, b = pinkyMcp - wrist;
            float denom = a.magnitude * b.magnitude;
            if (denom < 1e-5f) return 0f;
            float twiceArea = Mathf.Abs(a.x * b.y - a.y * b.x);
            return Mathf.Clamp01(twiceArea / denom);
        }

        public static bool ImplausibleJump(Vector3 previousPalm, Vector3 nextPalm, float dtSeconds,
            float maximumSpeedMetersPerSecond = 3.4f)
        {
            if (dtSeconds <= .001f || dtSeconds > .40f) return false;
            return Vector3.Distance(previousPalm, nextPalm) / dtSeconds > maximumSpeedMetersPerSecond;
        }
    }
}
