// Copyright 2026 OpenLensVR contributors. SPDX-License-Identifier: Apache-2.0
using System;
using UnityEngine;
using UnityEngine.UI;
namespace OpenLensVR.Interaction
{
    [RequireComponent(typeof(BoxCollider))]
    public sealed class WorldPressTarget : MonoBehaviour
    {
        [SerializeField] Graphic graphic;
        [SerializeField] Color idleColor = new Color(.18f, .23f, .35f, 1);
        [SerializeField] Color hoveredColor = new Color(.38f, .66f, .86f, 1);
        Action action;
        public void Configure(Action onPress, Graphic target = null)
        { action = onPress; graphic = target; SetHover(false); }
        public void Invoke() { action?.Invoke(); }
        public void SetHover(bool hovered)
        { if (graphic != null) graphic.color = hovered ? hoveredColor : idleColor; }
    }
}
