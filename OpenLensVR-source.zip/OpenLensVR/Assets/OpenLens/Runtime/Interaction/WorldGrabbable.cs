// Copyright 2026 OpenLensVR contributors. SPDX-License-Identifier: Apache-2.0
using UnityEngine;
namespace OpenLensVR.Interaction
{
    [RequireComponent(typeof(Collider))]
    public sealed class WorldGrabbable : MonoBehaviour
    {
        Transform originalParent;
        Rigidbody body;
        bool originalKinematic;
        public bool Held { get; private set; }
        public void PickUp(Transform attach)
        {
            if (Held || attach == null) return;
            originalParent = transform.parent;
            body = GetComponent<Rigidbody>();
            if (body != null) { originalKinematic = body.isKinematic; body.isKinematic = true; }
            Held = true;
            transform.SetParent(attach, true);
        }
        public void Release()
        {
            if (!Held) return;
            transform.SetParent(originalParent, true);
            if (body != null) body.isKinematic = originalKinematic;
            Held = false;
        }
        void OnDisable() { if (Held) Release(); }
    }
}
