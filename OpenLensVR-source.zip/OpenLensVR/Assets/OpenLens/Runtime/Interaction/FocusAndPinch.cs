// Copyright 2026 OpenLensVR contributors. SPDX-License-Identifier: Apache-2.0
using OpenLensVR.Core;
using OpenLensVR.Hands;
using OpenLensVR.Tracking;
using OpenLensVR.UI;
using UnityEngine;
namespace OpenLensVR.Interaction
{
    [DefaultExecutionOrder(100)]
    public sealed class FocusAndPinch : MonoBehaviour
    {
        [SerializeField] HeadPoseProvider head;
        [SerializeField] SingleHandTracker hand;
        [SerializeField] CalibrationPanel menu;
        [SerializeField] PresenceFeedback feedback;
        [SerializeField] float maxReach = 6f;
        WorldPressTarget focused;
        WorldGrabbable held;
        Transform handAnchor;
        Transform dot;
        float lastEmptyPinch = -10;
        public void Configure(HeadPoseProvider pose, SingleHandTracker tracked, CalibrationPanel panel, PresenceFeedback cues)
        {
            if (isActiveAndEnabled && hand != null) hand.PinchChanged -= OnPinch;
            head = pose; hand = tracked; menu = panel; feedback = cues;
            if (isActiveAndEnabled && hand != null) hand.PinchChanged += OnPinch;
        }

        void Start()
        {
            var marker = GameObject.CreatePrimitive(PrimitiveType.Sphere);
            marker.name = "Gaze Reticle"; Destroy(marker.GetComponent<Collider>());
            marker.transform.localScale = Vector3.one * .012f;
            dot = marker.transform;
            var material = new Material(Shader.Find("Unlit/Color"));
            material.color = new Color(.4f, .85f, 1f);
            marker.GetComponent<Renderer>().sharedMaterial = material;
            handAnchor = new GameObject("Grip Anchor").transform;
        }
        void OnEnable() { if (hand != null) hand.PinchChanged += OnPinch; }
        void OnDisable()
        {
            if (hand != null) hand.PinchChanged -= OnPinch;
            if (held != null) { held.Release(); held = null; }
        }
        void Update()
        {
            if (head == null) return;
            Pose pose = head.GetLatestPose();
            Ray ray = new Ray(pose.position, pose.rotation * Vector3.forward);
            var newTarget = (Physics.Raycast(ray, out RaycastHit hit, maxReach, ~(1 << 2)))
                ? hit.collider.GetComponentInParent<WorldPressTarget>() : null;
            if (focused != newTarget)
            {
                if (focused != null) focused.SetHover(false);
                focused = newTarget;
                if (focused != null) focused.SetHover(true);
            }
            if (dot != null) dot.SetPositionAndRotation(ray.GetPoint(hit.collider != null ? hit.distance : 2f), pose.rotation);
            if (hand != null && hand.HasHand)
            {
                handAnchor.position = hand.Joints[HandMath.IndexTip];
                handAnchor.rotation = pose.rotation;
            }
            if (held != null && (hand == null || !hand.HasHand)) { held.Release(); held = null; }
        }
        public void GazeClick()
        {
            if (focused != null) { focused.Invoke(); feedback?.Confirm(); }
        }
        public void ShowMenu() { menu?.Show(true); }
        void OnPinch(bool pressed)
        {
            if (!pressed) { if (held != null) { held.Release(); held = null; } return; }
            if (focused != null) { GazeClick(); return; }
            if (hand != null && hand.HasHand)
            {
                // Update the attach pose on the same accepted hand frame as the pinch event;
                // otherwise a grab can start from last display frame's fingertip position.
                handAnchor.position = hand.Joints[HandMath.IndexTip];
                handAnchor.rotation = head != null ? head.GetLatestPose().rotation : Quaternion.identity;
                Vector3 grip = hand.Joints[HandMath.IndexTip];
                Collider[] around = Physics.OverlapSphere(grip, .10f);
                foreach (var item in around)
                {
                    var grabbable = item.GetComponentInParent<WorldGrabbable>();
                    if (grabbable != null)
                    { held = grabbable; held.PickUp(handAnchor); feedback?.Confirm(); return; }
                }
            }
            if (Time.unscaledTime - lastEmptyPinch < .65f)
            { head?.Recenter(); feedback?.Confirm(); lastEmptyPinch = -10; }
            else lastEmptyPinch = Time.unscaledTime;
        }
    }
}
