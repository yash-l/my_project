// Copyright 2026 OpenLensVR contributors. SPDX-License-Identifier: Apache-2.0
using OpenLensVR.Core;
using UnityEngine;
namespace OpenLensVR.Interaction
{
    public sealed class PresenceFeedback : MonoBehaviour
    {
        AudioSource output;
        AudioClip click;
        void Awake()
        {
            output = gameObject.AddComponent<AudioSource>();
            output.spatialBlend = 0f; output.playOnAwake = false; output.volume = .12f;
            const int sampleRate = 16000;
            float[] samples = new float[1200];
            for (int i = 0; i < samples.Length; i++)
            {
                float t = i / (float)sampleRate;
                samples[i] = Mathf.Sin(2f * Mathf.PI * 670f * t) * (1f - i / (float)samples.Length);
            }
            click = AudioClip.Create("UI confirmation", samples.Length, 1, sampleRate, false);
            click.SetData(samples, 0);
        }
        public void Confirm()
        {
            if (SettingsStore.Current.audioFeedback && output != null && click != null) output.PlayOneShot(click);
            if (SettingsStore.Current.hapticFeedback) Handheld.Vibrate();
        }
    }
}
