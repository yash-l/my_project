// Copyright 2026 OpenLensVR contributors. SPDX-License-Identifier: Apache-2.0
using System;
using UnityEngine;

namespace OpenLensVR.Core
{
    public enum QualityMode { Comfort = 0, Balanced = 1, Performance = 2 }

    [Serializable]
    public sealed class ViewerSettings
    {
        // Optical starting values are placeholders for calibration, NOT the measured Nord CE5 viewer.
        public float interpupillaryMeters = 0.063f;
        public float lensToPanelMeters = 0.042f;
        public float physicalDisplayWidthMeters = 0.155f;
        public float physicalDisplayHeightMeters = 0.070f;
        public float distortionK1 = 0.12f;
        public float distortionK2 = 0.02f;
        public float handDepthScale = 1.0f;
        // Measured palm knuckle span (index MCP to pinky MCP); do not confuse with total palm width.
        public float assumedPalmWidthMeters = 0.078f;
        // Rotate raw ARCore CPU pixels clockwise for MediaPipe; verify on Nord CE5.
        public int handImageRotationDegrees = 0;
        public bool timewarp = true;
        public bool optionalVolumeControls;
        public bool audioFeedback = true;
        public bool hapticFeedback = false;
        public bool mirrorCameraX;
        public bool mirrorCameraY = false; // Raw camera pixel Y already increases down; calibrate in Gate C.
        public bool transposeCameraXY;
        public QualityMode quality = QualityMode.Balanced;
        public bool hasCompletedOnboarding;

        public void Sanitize()
        {
            interpupillaryMeters = Mathf.Clamp(interpupillaryMeters, 0.050f, 0.074f);
            lensToPanelMeters = Mathf.Clamp(lensToPanelMeters, 0.025f, 0.065f);
            physicalDisplayWidthMeters = Mathf.Clamp(physicalDisplayWidthMeters, 0.110f, 0.175f);
            physicalDisplayHeightMeters = Mathf.Clamp(physicalDisplayHeightMeters, 0.050f, 0.090f);
            distortionK1 = Mathf.Clamp(distortionK1, -0.5f, 0.7f);
            distortionK2 = Mathf.Clamp(distortionK2, -0.2f, 0.4f);
            handDepthScale = Mathf.Clamp(handDepthScale, 0.6f, 1.4f);
            // A missing field in an old saved JSON may deserialize as zero.
            if (assumedPalmWidthMeters < .045f || assumedPalmWidthMeters > .115f) assumedPalmWidthMeters = .078f;
            handImageRotationDegrees = ((handImageRotationDegrees % 360) + 360) % 360;
            handImageRotationDegrees = (handImageRotationDegrees / 90) * 90;
        }
    }

    public static class SettingsStore
    {
        const string Key = "OpenLensVR.ViewerSettings.v1";
        static ViewerSettings current;
        public static event Action Changed;
        public static ViewerSettings Current
        {
            get
            {
                if (current != null) return current;
                var json = PlayerPrefs.GetString(Key, "");
                try { current = string.IsNullOrEmpty(json) ? new ViewerSettings() : JsonUtility.FromJson<ViewerSettings>(json); }
                catch (Exception e) { Debug.LogWarning("[Settings] Corrupt preferences: " + e.Message); }
                if (current == null) current = new ViewerSettings();
                current.Sanitize();
                return current;
            }
        }
        public static void Save()
        {
            Current.Sanitize();
            PlayerPrefs.SetString(Key, JsonUtility.ToJson(Current));
            PlayerPrefs.Save();
            Changed?.Invoke();
        }
        public static void Reset()
        {
            current = new ViewerSettings();
            Save();
        }
    }
}
