// Copyright 2026 OpenLensVR contributors. SPDX-License-Identifier: Apache-2.0
using OpenLensVR.Core;
using OpenLensVR.Tracking;
using UnityEngine;

namespace OpenLensVR.Stereo
{
    /// <summary>
    /// Built-in Render Pipeline only. Three ordered cameras render left eye (-20), right eye
    /// (-19), then the unlit split-screen compositor (+20). Camera.onPreCull samples head pose
    /// for each eye; compositor receives a later sample and warps the *rendered* eye texture.
    /// No asynchronous GPU/compositor thread: this improves timing within the Unity frame only.
    /// </summary>
    public sealed class StereoCompositor : MonoBehaviour
    {
        [SerializeField] HeadPoseProvider head;
        [SerializeField] Shader compositorShader;
        [SerializeField] float nearClip = 0.055f;
        [SerializeField] float farClip = 80f;
        [SerializeField] float eyeResolutionScale = .85f;
        const int CompositeLayer = 29;
        readonly Camera[] eyes = new Camera[2];
        readonly RenderTexture[] textures = new RenderTexture[2];
        readonly Material[] materials = new Material[2];
        readonly Quaternion[] capturedRotation = new Quaternion[2];
        readonly Matrix4x4[] projections = new Matrix4x4[2];
        Camera compositor;
        Transform[] eyeTransforms = new Transform[2];
        int actualWidth, actualHeight;
        bool created;
        public float ResolutionScale => eyeResolutionScale;

        public void Configure(HeadPoseProvider pose, Shader shader) { head = pose; compositorShader = shader; }

        void OnEnable()
        {
            if (head == null) head = FindFirstObjectByType<HeadPoseProvider>();
            if (compositorShader == null) compositorShader = Shader.Find("OpenLensVR/TimewarpAndOptics");
            if (head == null || compositorShader == null)
            {
                Debug.LogError("[Stereo] Missing pose provider or compositor shader");
                enabled = false; return;
            }
            QualitySettings.vSyncCount = 0;
            Application.targetFrameRate = 60;
            Screen.sleepTimeout = SleepTimeout.NeverSleep;
            Screen.orientation = ScreenOrientation.LandscapeLeft;
            CreateRig();
            Camera.onPreCull += BeforeCull;
            SettingsStore.Changed += RefreshOptics;
        }

        void OnDisable()
        {
            Camera.onPreCull -= BeforeCull;
            SettingsStore.Changed -= RefreshOptics;
            DestroyRig();
        }

        public void SetResolution(float scale)
        {
            float next = Mathf.Clamp(Mathf.Round(scale * 20f) / 20f, .55f, 1f);
            if (Mathf.Abs(eyeResolutionScale - next) < .02f) return;
            eyeResolutionScale = next;
            // Avoid rebuilding cameras, changing only the textures when quality changes.
            RebuildEyeTextures();
        }

        void CreateRig()
        {
            if (created) return;
            for (int i = 0; i < 2; i++)
            {
                GameObject o = new GameObject(i == 0 ? "Left Eye" : "Right Eye");
                eyeTransforms[i] = o.transform;
                o.transform.SetParent(transform, false);
                eyes[i] = o.AddComponent<Camera>();
                eyes[i].stereoTargetEye = StereoTargetEyeMask.None;
                eyes[i].depth = -20 + i;
                eyes[i].nearClipPlane = nearClip;
                eyes[i].farClipPlane = farClip;
                eyes[i].clearFlags = CameraClearFlags.SolidColor;
                eyes[i].backgroundColor = new Color(.015f, .016f, .02f);
                eyes[i].cullingMask &= ~(1 << CompositeLayer);
                eyes[i].allowHDR = false;
                eyes[i].allowMSAA = false;
                materials[i] = new Material(compositorShader);
            }
            var comp = new GameObject("Late Warp Compositor");
            comp.transform.SetParent(transform, false);
            compositor = comp.AddComponent<Camera>();
            compositor.depth = 20;
            compositor.stereoTargetEye = StereoTargetEyeMask.None;
            compositor.orthographic = true;
            compositor.nearClipPlane = .01f;
            compositor.farClipPlane = 10f;
            compositor.clearFlags = CameraClearFlags.SolidColor;
            compositor.backgroundColor = Color.black;
            compositor.cullingMask = 1 << CompositeLayer;
            compositor.allowHDR = false;
            compositor.allowMSAA = false;
            for (int i = 0; i < 2; i++)
            {
                var quad = new GameObject(i == 0 ? "Left Warp" : "Right Warp");
                quad.layer = CompositeLayer;
                quad.transform.SetParent(comp.transform, false);
                quad.transform.localPosition = Vector3.forward;
                var mesh = new Mesh { name = "Eye Half " + i };
                float xmin = i == 0 ? -1f : 0f;
                float xmax = i == 0 ? 0f : 1f;
                mesh.vertices = new[] { new Vector3(xmin, -1), new Vector3(xmax, -1),
                    new Vector3(xmax, 1), new Vector3(xmin, 1) };
                mesh.uv = new[] { new Vector2(0, 0), new Vector2(1, 0),
                    new Vector2(1, 1), new Vector2(0, 1) };
                mesh.triangles = new[] { 0, 2, 1, 0, 3, 2 };
                mesh.bounds = new Bounds(Vector3.zero, Vector3.one * 1000f);
                quad.AddComponent<MeshFilter>().sharedMesh = mesh;
                quad.AddComponent<MeshRenderer>().sharedMaterial = materials[i];
            }
            created = true;
            RebuildEyeTextures();
            RefreshOptics();
            Debug.Log("[Stereo] Two render textures + late reprojection compositor initialized");
        }

        void RebuildEyeTextures()
        {
            if (!created) return;
            int width = Mathf.Max(256, Mathf.RoundToInt(Screen.width * .5f * eyeResolutionScale));
            int height = Mathf.Max(256, Mathf.RoundToInt(Screen.height * eyeResolutionScale));
            if (width == actualWidth && height == actualHeight) return;
            actualWidth = width; actualHeight = height;
            for (int i = 0; i < 2; i++)
            {
                if (textures[i] != null) { eyes[i].targetTexture = null; textures[i].Release(); Destroy(textures[i]); }
                textures[i] = new RenderTexture(width, height, 16, RenderTextureFormat.ARGB32)
                { name = $"EyeBuffer{i}", antiAliasing = 1, useMipMap = false };
                textures[i].Create();
                eyes[i].targetTexture = textures[i];
                materials[i].SetTexture("_MainTex", textures[i]);
            }
            Debug.Log($"[Stereo] Eye buffers {width}x{height}, scale {eyeResolutionScale:F2}");
        }

        void RefreshOptics()
        {
            var s = SettingsStore.Current;
            for (int i = 0; i < 2; i++)
            {
                projections[i] = OpticalMath.EyeProjection(i == 1, s.interpupillaryMeters,
                    s.physicalDisplayWidthMeters, s.physicalDisplayHeightMeters,
                    s.lensToPanelMeters, nearClip, farClip);
                if (eyes[i] != null) eyes[i].projectionMatrix = projections[i];
                if (materials[i] != null)
                {
                    materials[i].SetFloat("_K1", s.distortionK1);
                    materials[i].SetFloat("_K2", s.distortionK2);
                    materials[i].SetFloat("_WarpEnabled", s.timewarp ? 1f : 0f);
                    materials[i].SetMatrix("_EyeProjection", projections[i]);
                }
            }
        }

        void BeforeCull(Camera camera)
        {
            if (head == null || !created) return;
            if (camera == eyes[0] || camera == eyes[1])
            {
                int i = camera == eyes[0] ? 0 : 1;
                var pose = head.GetLatestPose();
                // Preserve position of the head; the eye baseline is expressed in head coordinates.
                float offset = (i == 0 ? -.5f : .5f) * SettingsStore.Current.interpupillaryMeters;
                eyeTransforms[i].SetPositionAndRotation(pose.position + pose.rotation * new Vector3(offset, 0, 0), pose.rotation);
                capturedRotation[i] = pose.rotation;
            }
            else if (camera == compositor)
            {
                // This occurs after the two eyes render. It is intentionally the latest CPU pose
                // available for this frame, rather than the pose saved at eye rendering time.
                var latePose = head.GetLatePredictedPose();
                for (int i = 0; i < 2; i++)
                {
                    var delta = OpticalMath.LateToRendered(capturedRotation[i], latePose.rotation);
                    float angle = Quaternion.Angle(capturedRotation[i], latePose.rotation);
                    bool valid = angle < 18f && !float.IsNaN(delta.x);
                    materials[i].SetMatrix("_LateToRendered", Matrix4x4.Rotate(valid ? delta : Quaternion.identity));
                    materials[i].SetFloat("_WarpEnabled", SettingsStore.Current.timewarp && valid ? 1 : 0);
                }
            }
        }

        void DestroyRig()
        {
            if (!created) return;
            for (int i = 0; i < 2; i++)
            {
                if (eyes[i] != null) Destroy(eyes[i].gameObject);
                if (textures[i] != null) { textures[i].Release(); Destroy(textures[i]); }
                if (materials[i] != null) Destroy(materials[i]);
                eyes[i] = null; textures[i] = null; materials[i] = null;
            }
            if (compositor != null) Destroy(compositor.gameObject);
            compositor = null; created = false;
        }
    }
}
