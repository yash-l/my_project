// Copyright 2026 OpenLensVR contributors. SPDX-License-Identifier: Apache-2.0
using UnityEngine;

namespace OpenLensVR.Stereo
{
    public static class OpticalMath
    {
        // Project each eye through the physical *half* of the phone panel. Lens centers and
        // actual screen dimensions must be calibrated; incorrectly measured viewers cause strain.
        public static Matrix4x4 EyeProjection(bool right, float ipdMeters,
            float screenWidthMeters, float screenHeightMeters, float lensToScreenMeters,
            float near, float far)
        {
            float eyeHalf = screenWidthMeters * 0.25f;
            float lensX = right ? ipdMeters * .5f : -ipdMeters * .5f;
            float panelHalfCenter = right ? screenWidthMeters * .25f : -screenWidthMeters * .25f;
            float leftX = panelHalfCenter - eyeHalf - lensX;
            float rightX = panelHalfCenter + eyeHalf - lensX;
            float s = near / Mathf.Max(0.001f, lensToScreenMeters);
            return Matrix4x4.Frustum(leftX * s, rightX * s,
                -screenHeightMeters * .5f * s, screenHeightMeters * .5f * s, near, far);
        }

        // Maps a viewing ray in the *late* head's coordinate frame into the orientation at
        // which the eye texture was rendered. Translation isn't reconstructed (rotation only).
        public static Quaternion LateToRendered(Quaternion rendered, Quaternion late)
            => Quaternion.Inverse(rendered) * late;

        public static Vector2 ReprojectUv(Vector2 lateUv, Matrix4x4 projection, Quaternion rendered, Quaternion late)
        {
            float x = (lateUv.x * 2f - 1f - projection[0, 2]) / projection[0, 0];
            float y = (lateUv.y * 2f - 1f - projection[1, 2]) / projection[1, 1];
            Vector3 oldRay = LateToRendered(rendered, late) * new Vector3(x, y, 1f);
            if (oldRay.z <= 0f) return new Vector2(-1, -1);
            float oldX = projection[0, 0] * (oldRay.x / oldRay.z) + projection[0, 2];
            float oldY = projection[1, 1] * (oldRay.y / oldRay.z) + projection[1, 2];
            return new Vector2((oldX + 1) * .5f, (oldY + 1) * .5f);
        }
    }
}
