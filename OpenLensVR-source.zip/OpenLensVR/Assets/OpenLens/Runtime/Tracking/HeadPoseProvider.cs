// Copyright 2026 OpenLensVR contributors. SPDX-License-Identifier: Apache-2.0
using System;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.XR.ARFoundation;

namespace OpenLensVR.Tracking
{
    public enum HeadTrackingMode { Waiting, SixDof, ThreeDof }

    /// <summary>Samples ARCore HandheldARInputDevice directly, without a second VR loader.
    /// A conservative 3DoF fallback uses the Android attitude sensor when AR is unavailable.</summary>
    public sealed class HeadPoseProvider : MonoBehaviour
    {
        [SerializeField] ARSession arSession;
        [SerializeField] ARCameraManager arCamera;
        [SerializeField] Transform arOrigin;
        [SerializeField] Vector3 cameraToEyes = new Vector3(.05f, -.015f, -.055f);
        [SerializeField] bool force3Dof;
        InputAction arPosition;
        InputAction arRotation;
        Quaternion fallbackReference = Quaternion.identity;
        Quaternion centerYaw = Quaternion.identity;
        Vector3 centerPosition;
        Quaternion lastValid = Quaternion.identity;
        Quaternion lastRawRotation = Quaternion.identity;
        Vector3 lastRawPosition;
        Vector3 lastPosition;
        bool haveFallbackReference;
        bool recenterPending = true;
        bool trackingProtected;
        float trackingLostSince;
        readonly PosePredictor predictor = new PosePredictor();
        public HeadTrackingMode Mode { get; private set; } = HeadTrackingMode.Waiting;
        public event Action<HeadTrackingMode> ModeChanged;
        public bool IsArTracking => ARSession.state == ARSessionState.SessionTracking && !trackingProtected;
        public float TrackingLostSeconds => Mode == HeadTrackingMode.SixDof ? 0 : Time.unscaledTime - trackingLostSince;

        public void Configure(ARSession session, ARCameraManager camera, Transform origin)
        { arSession = session; arCamera = camera; arOrigin = origin; }

        void OnEnable()
        {
            // ARCore exposes handheld camera pose via its Input System device.
            arPosition = new InputAction("ARDevicePosition", InputActionType.Value, "<HandheldARInputDevice>/devicePosition");
            arRotation = new InputAction("ARDeviceRotation", InputActionType.Value, "<HandheldARInputDevice>/deviceRotation");
            arPosition.Enable(); arRotation.Enable();
            if (AttitudeSensor.current != null) InputSystem.EnableDevice(AttitudeSensor.current);
            trackingLostSince = Time.unscaledTime;
        }
        void OnDisable()
        {
            arPosition?.Disable(); arRotation?.Disable(); arPosition?.Dispose(); arRotation?.Dispose();
            arPosition = null; arRotation = null;
        }
        void Update() { GetLatestPose(); }

        public Pose GetLatestPose()
        {
            bool arReady = !force3Dof && !trackingProtected && IsArTracking &&
                arPosition != null && arPosition.activeControl != null &&
                arRotation != null && arRotation.activeControl != null;
            Pose raw;
            HeadTrackingMode next;
            if (arReady)
            {
                Vector3 localPosition = arPosition.ReadValue<Vector3>();
                Quaternion localRotation = arRotation.ReadValue<Quaternion>();
                if (!IsFinite(localPosition) || !ValidQuaternion(localRotation))
                {
                    raw = ThreeDofPose(); next = HeadTrackingMode.ThreeDof;
                }
                else
                {
                    raw = new Pose(localPosition + localRotation * cameraToEyes, localRotation);
                    if (arOrigin != null) raw = new Pose(arOrigin.TransformPoint(raw.position), arOrigin.rotation * raw.rotation);
                    next = HeadTrackingMode.SixDof;
                }
            }
            else
            {
                raw = ThreeDofPose();
                next = AttitudeSensor.current != null ? HeadTrackingMode.ThreeDof : HeadTrackingMode.Waiting;
            }
            if (next != Mode)
            {
                // Keep the visible orientation continuous when AR tracking is lost or restored.
                // The 3DoF fallback starts with the last AR pose, not arbitrary Android axes.
                if (next == HeadTrackingMode.SixDof && Mode != HeadTrackingMode.Waiting)
                {
                    haveFallbackReference = false;
                    centerYaw = lastValid * Quaternion.Inverse(raw.rotation);
                    centerPosition = raw.position - Quaternion.Inverse(centerYaw) * lastPosition;
                    recenterPending = false;
                }
                Mode = next;
                predictor.Reset();
                trackingLostSince = Time.unscaledTime;
                ModeChanged?.Invoke(Mode);
                Debug.Log("[Pose] Tracking mode -> " + Mode);
            }
            if (recenterPending)
            {
                centerYaw = Quaternion.Euler(0, -raw.rotation.eulerAngles.y, 0);
                centerPosition = raw.position;
                recenterPending = false;
            }
            var result = new Pose(centerYaw * (raw.position - centerPosition), centerYaw * raw.rotation);
            lastRawRotation = raw.rotation;
            lastRawPosition = raw.position;
            lastValid = result.rotation;
            lastPosition = result.position;
            predictor.Push(result.rotation, Time.unscaledTime);
            return result;
        }

        Pose ThreeDofPose()
        {
            var sensor = AttitudeSensor.current;
            if (sensor == null) return new Pose(lastPosition, lastValid);
            Quaternion value = sensor.attitude.ReadValue();
            if (!ValidQuaternion(value)) return new Pose(lastPosition, lastValid);
            // Android sensor-to-Unity axes in landscape-left. A further orientation correction
            // may be required on some OEM sensor implementations; measure before deploying.
            var unityOrientation = Quaternion.Euler(90, 0, 0) * new Quaternion(value.x, value.y, -value.z, -value.w);
            if (!haveFallbackReference)
            {
                fallbackReference = lastRawRotation * Quaternion.Inverse(unityOrientation);
                haveFallbackReference = true;
            }
            return new Pose(lastRawPosition, fallbackReference * unityOrientation);
        }

        /// <summary>Estimate the REAR CAMERA pose in our recentered VR world from the calibrated
        /// camera-to-eye offset. This is much safer for hand points than treating the eye midpoint
        /// as the camera center. Because camera sensor timestamps are not matched to a historical
        /// ARCore pose yet, it remains an estimate sampled at CPU-frame acquisition.</summary>
        public Pose GetApproximateRearCameraPose()
        {
            var eyes = GetLatestPose();
            return new Pose(eyes.position - eyes.rotation * cameraToEyes, eyes.rotation);
        }

        public Pose GetLatePredictedPose(float horizonSeconds = .008f)
        {
            Pose sampled = GetLatestPose();
            return new Pose(sampled.position, predictor.Predict(sampled.rotation, horizonSeconds));
        }
        public void Recenter() { recenterPending = true; predictor.Reset(); Debug.Log("[Pose] Recenter requested"); }

        public void ProtectFromHeat(bool protect)
        {
            if (trackingProtected == protect) return;
            trackingProtected = protect;
            if (arSession != null) arSession.enabled = !protect;
            if (arCamera != null) arCamera.enabled = !protect;
            recenterPending = true;
            Debug.LogWarning("[Pose] Thermal 3DoF protection " + (protect ? "enabled" : "disabled"));
        }

        static bool Finite(float x) => !float.IsNaN(x) && !float.IsInfinity(x);
        static bool IsFinite(Vector3 value) => Finite(value.x) && Finite(value.y) && Finite(value.z);
        static bool ValidQuaternion(Quaternion value) =>
            Finite(value.x) && Finite(value.y) && Finite(value.z) && Finite(value.w) &&
            Quaternion.Dot(value, value) > .1f;
    }
}
