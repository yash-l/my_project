// Copyright 2026 OpenLensVR contributors. SPDX-License-Identifier: Apache-2.0
using UnityEngine;
namespace OpenLensVR.Tracking
{
    // Derives short angular velocity from successive pose samples. The prediction horizon is
    // deliberately small (<= 12 ms): overprediction is more disturbing than mild latency.
    public sealed class PosePredictor
    {
        Quaternion lastRotation;
        Vector3 axis = Vector3.up;
        float angularVelocityDeg;
        float lastTime;
        bool ready;
        public void Push(Quaternion rotation, float time)
        {
            if (!ready) { lastRotation = rotation; lastTime = time; ready = true; return; }
            float dt = time - lastTime;
            if (dt < .006f || dt > .25f) return;
            Quaternion delta = rotation * Quaternion.Inverse(lastRotation);
            delta.ToAngleAxis(out float angle, out Vector3 foundAxis);
            if (angle > 180) angle -= 360;
            if (Mathf.Abs(angle) >= .04f && foundAxis.sqrMagnitude > .5f)
            {
                axis = foundAxis.normalized;
                float speed = Mathf.Clamp(angle / dt, -600f, 600f);
                angularVelocityDeg = Mathf.Lerp(angularVelocityDeg, speed, .35f);
            }
            else angularVelocityDeg *= .85f;
            lastRotation = rotation;
            lastTime = time;
        }
        public Quaternion Predict(Quaternion rotation, float aheadSeconds)
        {
            if (!ready) return rotation;
            return Quaternion.AngleAxis(angularVelocityDeg * Mathf.Clamp(aheadSeconds, 0, .012f), axis) * rotation;
        }
        public void Reset() { ready = false; angularVelocityDeg = 0f; }
    }
}
