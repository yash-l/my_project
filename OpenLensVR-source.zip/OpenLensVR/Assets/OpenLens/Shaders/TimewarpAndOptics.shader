// Copyright 2026 OpenLensVR contributors. SPDX-License-Identifier: Apache-2.0
Shader "OpenLensVR/TimewarpAndOptics"
{
    Properties { _MainTex ("Rendered Eye", 2D) = "black" {} }
    SubShader
    {
        Tags { "Queue"="Overlay" "RenderType"="Opaque" }
        Pass
        {
            ZWrite Off ZTest Always Cull Off
            CGPROGRAM
            #pragma vertex vert
            #pragma fragment frag
            #include "UnityCG.cginc"
            sampler2D _MainTex;
            float4x4 _LateToRendered;
            float4x4 _EyeProjection;
            float _WarpEnabled, _K1, _K2;
            struct appdata { float4 vertex : POSITION; float2 uv : TEXCOORD0; };
            struct v2f { float4 vertex : SV_POSITION; float2 uv : TEXCOORD0; };
            v2f vert(appdata input)
            {
                v2f output;
                // Geometry is authored directly in clip-space so the independent compositor
                // camera never introduces perspective or another optical transformation.
                output.vertex = float4(input.vertex.xy, 0, 1);
                output.uv = input.uv;
                return output;
            }
            fixed4 frag(v2f input) : SV_Target
            {
                float2 lens = input.uv * 2.0 - 1.0;
                float r2 = dot(lens, lens);
                // Lens inverse is approximated with an adjustable polynomial in normalized
                // half-screen coordinates. Must be measured for the actual viewer.
                float radial = 1 + _K1 * r2 + _K2 * r2 * r2;
                float2 uv = lens * radial * 0.5 + 0.5;
                if (_WarpEnabled > 0.5)
                {
                    // Convert desired *late* pixel to a ray, rotate that ray back into the
                    // previously rendered camera, then project onto the original eye texture.
                    float x = (uv.x * 2 - 1 - _EyeProjection[0][2]) / _EyeProjection[0][0];
                    float y = (uv.y * 2 - 1 - _EyeProjection[1][2]) / _EyeProjection[1][1];
                    float3 ray = mul((float3x3)_LateToRendered, float3(x, y, 1));
                    if (ray.z <= 0.001) return fixed4(0, 0, 0, 1);
                    uv.x = 0.5 * (1 + _EyeProjection[0][0] * ray.x / ray.z + _EyeProjection[0][2]);
                    uv.y = 0.5 * (1 + _EyeProjection[1][1] * ray.y / ray.z + _EyeProjection[1][2]);
                }
                // Invalid regions become black, never repeat/smear image borders.
                if (uv.x < 0 || uv.x > 1 || uv.y < 0 || uv.y > 1) return fixed4(0, 0, 0, 1);
                return tex2D(_MainTex, uv);
            }
            ENDCG
        }
    }
    Fallback Off
}
