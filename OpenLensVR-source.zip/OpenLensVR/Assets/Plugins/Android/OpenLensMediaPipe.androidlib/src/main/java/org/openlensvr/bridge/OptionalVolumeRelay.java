// Copyright 2026 OpenLensVR contributors. SPDX-License-Identifier: Apache-2.0
package org.openlensvr.bridge;

import android.app.Activity;
import android.os.SystemClock;
import android.view.KeyEvent;
import android.view.View;
import java.lang.reflect.Method;

/** Best-effort opt-in volume interception: View key listeners are not guaranteed on OEM devices.
 * Do not interfere with normal volume handling when this feature is disabled. */
public final class OptionalVolumeRelay {
    private View target;
    private long pressedAt;
    private String unityName;
    private boolean active;
    private View.OnKeyListener listener;

    public void setEnabled(Activity activity, String callbackObject, boolean enable) {
        unityName = callbackObject;
        activity.runOnUiThread(() -> {
            target = activity.getWindow().getDecorView();
            active = enable;
            listener = (view, keyCode, event) -> {
                if (!active || (keyCode != KeyEvent.KEYCODE_VOLUME_UP && keyCode != KeyEvent.KEYCODE_VOLUME_DOWN))
                    return false;
                if (event.getAction() == KeyEvent.ACTION_DOWN && event.getRepeatCount() == 0) {
                    pressedAt = SystemClock.uptimeMillis(); return true;
                }
                if (event.getAction() == KeyEvent.ACTION_UP) {
                    long held = SystemClock.uptimeMillis() - pressedAt;
                    send(held >= 600 ? "long" : "short"); return true;
                }
                return true;
            };
            target.setFocusableInTouchMode(true);
            target.setOnKeyListener(listener);
            target.requestFocus();
        });
    }
    public void disable() { active = false; if (target != null) target.post(() -> target.setOnKeyListener(null)); }
    private void send(String message) {
        try {
            Class<?> unity = Class.forName("com.unity3d.player.UnityPlayer");
            Method method = unity.getMethod("UnitySendMessage", String.class, String.class, String.class);
            method.invoke(null, unityName, "OnVolumeMessage", message);
        } catch (Throwable ignored) { }
    }
}
