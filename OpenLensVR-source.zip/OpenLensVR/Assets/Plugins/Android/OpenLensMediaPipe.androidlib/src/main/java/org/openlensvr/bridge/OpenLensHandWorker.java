// Copyright 2026 OpenLensVR contributors. SPDX-License-Identifier: Apache-2.0
package org.openlensvr.bridge;

import android.content.Context;
import android.graphics.Bitmap;
import android.os.Handler;
import android.os.HandlerThread;
import android.util.Log;

import com.google.mediapipe.framework.image.BitmapImageBuilder;
import com.google.mediapipe.framework.image.MPImage;
import com.google.mediapipe.tasks.components.containers.Category;
import com.google.mediapipe.tasks.components.containers.Landmark;
import com.google.mediapipe.tasks.components.containers.NormalizedLandmark;
import com.google.mediapipe.tasks.core.BaseOptions;
import com.google.mediapipe.tasks.vision.core.RunningMode;
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarker;
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarkerResult;

import java.io.File;
import java.io.FileInputStream;
import java.lang.reflect.Method;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

/** One real rear-camera stream (supplied by Unity), one hand model, zero network calls.
 * Frames are dropped while inference is busy to bound age rather than piling up latency.
 * The model, Bitmap, and detector calls live on the same HandlerThread. */
public final class OpenLensHandWorker {
    private static final String TAG = "OpenLensHandWorker";
    private HandlerThread workerThread;
    private Handler handler;
    private volatile HandLandmarker model;
    private Bitmap bitmap;
    private volatile boolean running;
    private final AtomicBoolean busy = new AtomicBoolean(false);
    private String callbackObject;
    private long lastTimestamp = -1;
    private int consecutiveErrors;

    public void initialize(Context context, String modelFile, String unityTarget) {
        if (running) throw new IllegalStateException("Worker already running");
        callbackObject = unityTarget;
        if (!new File(modelFile).isFile()) throw new IllegalArgumentException("MediaPipe task model missing");
        workerThread = new HandlerThread("OpenLens-MediaPipe");
        workerThread.start();
        handler = new Handler(workerThread.getLooper());
        Context appContext = context.getApplicationContext();
        running = true;
        handler.post(() -> {
            try {
                ByteBuffer mapped;
                try (FileInputStream stream = new FileInputStream(modelFile)) {
                    mapped = stream.getChannel().map(FileChannel.MapMode.READ_ONLY, 0, new File(modelFile).length());
                }
                BaseOptions base = BaseOptions.builder().setModelAssetBuffer(mapped).build();
                HandLandmarker.HandLandmarkerOptions opts = HandLandmarker.HandLandmarkerOptions.builder()
                    .setBaseOptions(base).setNumHands(1).setRunningMode(RunningMode.VIDEO)
                    .setMinHandDetectionConfidence(.57f)
                    .setMinHandPresenceConfidence(.55f)
                    .setMinTrackingConfidence(.52f)
                    .build();
                model = HandLandmarker.createFromOptions(appContext, opts);
                Log.i(TAG, "Single-hand landmarker initialized");
                sendMethod("OnNativeHandStatus", "ready");
            } catch (Throwable error) {
                Log.e(TAG, "Landmarker initialization failed", error);
                sendMethod("OnNativeHandStatus", "Model initialization failed: " + error.getMessage());
            }
        });
    }

    public void submit(byte[] rgba, int width, int height, long timestampMs) {
        if (!running || model == null || handler == null || rgba == null ||
            width <= 0 || height <= 0 || rgba.length != width * height * 4) return;
        if (!busy.compareAndSet(false, true)) return;
        // AndroidJavaObject bridges byte[] into Java memory on submit. The caller can reuse
        // its C# byte buffer; this Java buffer lives through completion of this worker job.
        handler.post(() -> {
            try {
                if (!running || model == null) return;
                if (bitmap == null || bitmap.getWidth() != width || bitmap.getHeight() != height) {
                    if (bitmap != null) bitmap.recycle();
                    bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
                }
                bitmap.copyPixelsFromBuffer(ByteBuffer.wrap(rgba));
                MPImage input = new BitmapImageBuilder(bitmap).build();
                long monotonicallyIncreasing = Math.max(lastTimestamp + 1, timestampMs);
                lastTimestamp = monotonicallyIncreasing;
                long t0 = System.nanoTime();
                HandLandmarkerResult result = model.detectForVideo(input, monotonicallyIncreasing);
                float inferenceMs = (System.nanoTime() - t0) / 1_000_000f;
                sendMethod("OnNativeHandResult", makePacket(result, timestampMs, width, height, inferenceMs));
                consecutiveErrors = 0;
            } catch (Throwable error) {
                Log.e(TAG, "Inference failed", error);
                if (++consecutiveErrors >= 5) {
                    sendMethod("OnNativeHandStatus", "Repeated MediaPipe inference errors: " + error.getMessage());
                    consecutiveErrors = 0;
                }
            } finally {
                busy.set(false);
            }
        });
    }

    private static String makePacket(HandLandmarkerResult result, long id, int width, int height,
                                     float inferenceMs) {
        List<List<NormalizedLandmark>> all = result.landmarks();
        List<List<Landmark>> allMetric = result.worldLandmarks();
        List<List<Category>> handedness = result.handedness();
        List<NormalizedLandmark> points = all.isEmpty() ? null : all.get(0);
        List<Landmark> world = allMetric.isEmpty() ? null : allMetric.get(0);
        float handScore = handedness.isEmpty() || handedness.get(0).isEmpty()
            ? 0f : handedness.get(0).get(0).score();
        StringBuilder json = new StringBuilder(2600);
        json.append("{\"timestampMs\":").append(id)
            .append(",\"width\":").append(width)
            .append(",\"height\":").append(height)
            .append(",\"inferenceMs\":").append(inferenceMs)
            .append(",\"handednessScore\":").append(handScore)
            .append(",\"points\":[");
        if (points != null) {
            for (int i = 0; i < points.size(); ++i) {
                if (i > 0) json.append(',');
                NormalizedLandmark p = points.get(i);
                addPoint(json, p.x(), p.y(), p.z());
            }
        }
        json.append("],\"worldPoints\":[");
        if (world != null && world.size() == 21) {
            for (int i = 0; i < world.size(); ++i) {
                if (i > 0) json.append(',');
                Landmark p = world.get(i);
                addPoint(json, p.x(), p.y(), p.z());
            }
        }
        json.append("]}");
        return json.toString();
    }

    private static void addPoint(StringBuilder json, float x, float y, float z) {
        // NaN/Infinity are not valid JSON; Unity's gate rejects invalid landmark geometry.
        json.append("{\"x\":").append(Float.isFinite(x) ? x : 0f)
            .append(",\"y\":").append(Float.isFinite(y) ? y : 0f)
            .append(",\"z\":").append(Float.isFinite(z) ? z : 0f).append('}');
    }

    private void sendMethod(String methodName, String payload) {
        if (!running) return;
        try {
            // Reflection keeps the library independent of a compile-time UnityPlayer JAR.
            Class<?> unity = Class.forName("com.unity3d.player.UnityPlayer");
            Method send = unity.getMethod("UnitySendMessage", String.class, String.class, String.class);
            send.invoke(null, callbackObject, methodName, payload);
        } catch (Throwable error) { Log.e(TAG, "Unity callback failed", error); }
    }

    public void close() {
        running = false;
        if (handler != null) handler.post(() -> {
            if (model != null) { model.close(); model = null; }
            if (bitmap != null) { bitmap.recycle(); bitmap = null; }
        });
        if (workerThread != null) workerThread.quitSafely();
        handler = null;
        workerThread = null;
    }
}
