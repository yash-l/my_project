# Architecture decisions

**Original codebase:** OpenLensVR.* only, no CardboardXR or Google Cardboard SDK. Unity/ARCore are third-party dependencies, not forked projects.

**Rendering:** Unity 6 Built-in Render Pipeline; `Camera.onPreCull` injects sampled head pose for each eye and compositor. Each eye is rendered to its own 16-bit-depth ARGB32 RenderTexture with a calibrated asymmetric projection. A final camera draws split-screen quads, reconstructs rays, maps late pose rays back to render pose, applies radial lens correction, returns black outside valid eye UV.

**Tracking:** `HeadPoseProvider` gets ARCore handheld device rotation/position from Unity Input System; if missing, `AttitudeSensor` provides 3DoF. Both modes pass through recenter transform and `PosePredictor`. No second XR loader.

**Hand input:** ARCore owns camera. `SingleHandTracker` copies downscaled XRCpuImage RGBA into native MediaPipe Task worker on Android. MediaPipe builds palm detection and 21-landmark classification; Java serial worker sends JSON to Unity on the main thread; result is attached to its submission-time pose and camera intrinsics by request timestamp; true AR camera sensor-time synchronization is pending; One-Euro smoothing and pinch logic run in C#; view draws actual hand skeleton. Missing model/bridge shows hand unavailable.

**Monocular hand depth:** approximately depth = focal_px * assumed_palm_width_m / measured_palm_span_px. Not calibrated sensor depth and not proper stereo hand occlusion. User calibration only changes displayed depth.

**Interactions:** `FocusAndPinch` raycasts gaze to actual world-space colliders and invokes local callbacks on pinch. Near-object `WorldGrabbable` follows a hand anchor while pinched; no controller SDK. Double pinch in empty space recenters. Optional Java decor-view volume listener can be enabled but is not guaranteed by Android.

**Thermal:** `AndroidDeviceStatus` polls the Android PowerManager (10s cadence); `QualityPolicy` makes deterministic scale/HandHz/thermal protection decisions; `AdaptiveQualityController` acts on them. Recovery requires consecutive cool windows. Fully stop ARCore capture in severe protection; 3DoF head rotation remains.

**Assemblies:** one `OpenLensVR.Runtime` assembly to avoid circular Unity assembly dependencies across UI/Interaction, plus isolated `OpenLensVR.Editor` and `OpenLensVR.EditModeTests` assemblies; runtime code is separated into seven functional namespaces and directories. Future versions can split into narrower interfaces/assemblies once the integration contracts are stabilized.
